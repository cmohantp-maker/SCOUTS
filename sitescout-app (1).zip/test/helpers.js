import { openDb } from '../src/db.js';
import { createApp } from '../src/app.js';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export function startServer(envOver = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ss-'));
  const db = openDb(':memory:');
  const env = {
    production: false, otpMode: 'demo', paymentsMode: 'demo', allowManualGps: false,
    adminPhones: ['9000000001'], authRateLimit: 100000, ...envOver,
  };
  const app = createApp({ db, env, photoDir: path.join(dir, 'photos'), publicDir: path.resolve('public') });
  return new Promise((resolve) => {
    const server = app.listen(0, () => {
      const base = `http://127.0.0.1:${server.address().port}`;
      resolve({ db, base, close: () => server.close() });
    });
  });
}

// A tiny browser: keeps cookies, sends JSON.
export function client(base) {
  let cookie = '';
  const call = async (method, url, body) => {
    const res = await fetch(base + url, {
      method,
      headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}) },
      body: method === 'GET' ? undefined : JSON.stringify(body || {}),
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* not json */ }
    return { status: res.status, json, text, headers: res.headers };
  };
  return {
    get: (u) => call('GET', u),
    post: (u, b) => call('POST', u, b),
    put: (u, b) => call('PUT', u, b),
    async signup(phone, profile = {}) {
      const a = await call('POST', '/api/auth/request', { phone });
      const v = await call('POST', '/api/auth/verify', { phone, code: a.json.demoCode, name: 'Test ' + phone.slice(-4), ...profile });
      if (v.status !== 200) throw new Error('signup failed ' + v.text);
      return v.json.user;
    },
  };
}

// Smallest thing that passes the photo checks: JPEG magic bytes and enough length.
export const PHOTO = 'data:image/jpeg;base64,' + Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(900, 7), Buffer.from([0xff, 0xd9])]).toString('base64');

export const siteBody = (over = {}) => ({
  lat: 11.0168, lng: 76.9558, acc: 10, gpsSrc: 'gps', locality: 'RS Puram', name: 'Test site',
  type: 'Residential', sub: 'Villa', stage: 3, area: 2000, budget: '₹50L–1Cr',
  owner: { name: 'Owner One', phone: '9000012345' }, architect: { name: 'Arch', phone: '' },
  engineer: { name: '', phone: '' }, builder: { name: 'Builder', phone: '9000099999' },
  ownerNotified: true, photo: PHOTO, ...over,
});
