import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startServer, client, siteBody } from './helpers.js';

let s;
before(async () => { s = await startServer(); });
after(() => s.close());

const admin = async () => { const c = client(s.base); await c.signup('9000000001'); return c; };
const scout = async (phone) => { const c = client(s.base); await c.signup(phone, { role: 'scout', kind: 'Public member' }); return c; };
const supplier = async (phone, trades = ['steel', 'cement', 'tiles']) => {
  const c = client(s.base); await c.signup(phone, { role: 'supplier', trades }); return c;
};
const verify = async (adm, code) => (await adm.post(`/api/admin/sites/${code}/approve`)).json;

test('login: code needed, new users need a name, admin phone becomes admin', async () => {
  const c = client(s.base);
  assert.equal((await c.post('/api/auth/request', { phone: '12345' })).status, 400);
  const a = await c.post('/api/auth/request', { phone: '9811100001' });
  assert.equal(a.json.exists, false);
  assert.equal((await c.post('/api/auth/verify', { phone: '9811100001', code: '000000' })).status, 400);
  assert.equal((await c.post('/api/auth/verify', { phone: '9811100001', code: a.json.demoCode })).status, 400, 'no name yet');
  const ok = await c.post('/api/auth/verify', { phone: '9811100001', code: a.json.demoCode, name: 'Asha', role: 'scout' });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.user.role, 'scout');
  assert.equal((await c.get('/api/me')).json.user.name, 'Asha');
  const adm = await admin();
  assert.equal((await adm.get('/api/me')).json.user.role, 'admin');
  // cannot pick admin by asking for it
  const x = client(s.base);
  const u = await x.signup('9811100002', { role: 'admin' });
  assert.equal(u.role, 'scout');
});

test('wrong codes lock the code after 5 tries', async () => {
  const c = client(s.base);
  const a = await c.post('/api/auth/request', { phone: '9811100003' });
  for (let i = 0; i < 5; i++) await c.post('/api/auth/verify', { phone: '9811100003', code: '111111', name: 'X' });
  const r = await c.post('/api/auth/verify', { phone: '9811100003', code: a.json.demoCode, name: 'X' });
  assert.equal(r.status, 429);
});

test('role guards', async () => {
  const anon = client(s.base);
  assert.equal((await anon.get('/api/wallet')).status, 401);
  const sc = await scout('9811100010');
  assert.equal((await sc.get('/api/admin/sites')).status, 403);
  assert.equal((await sc.get('/api/leads')).status, 403);
  const su = await supplier('9811100011');
  assert.equal((await su.post('/api/sites', siteBody())).status, 403);
});

test('one report per site, across different people', async () => {
  const a = await scout('9811100020');
  const b = await scout('9811100021');
  const first = await a.post('/api/sites', siteBody({ lat: 11.05, lng: 77.0 }));
  assert.equal(first.status, 201);
  const near = await b.post('/api/sites', siteBody({ lat: 11.05009, lng: 77.0 })); // about 10 m
  assert.equal(near.status, 409);
  assert.equal(near.json.own, false);
  assert.ok(!JSON.stringify(near.json).includes('SS-'), 'does not leak the other site code');
  const own = await a.post('/api/sites', siteBody({ lat: 11.05, lng: 77.00005 }));
  assert.equal(own.status, 409);
  assert.equal(own.json.own, true);
  const chk = await b.post('/api/sites/check', { lat: 11.05, lng: 77.0 });
  assert.equal(chk.json.duplicate, true);
  const far = await b.post('/api/sites', siteBody({ lat: 11.052, lng: 77.0 })); // about 220 m
  assert.equal(far.status, 201);
});

test('two people reporting the same spot at the same moment: only one wins', async () => {
  const a = await scout('9811100030');
  const b = await scout('9811100031');
  const [r1, r2] = await Promise.all([
    a.post('/api/sites', siteBody({ lat: 11.2, lng: 77.1 })),
    b.post('/api/sites', siteBody({ lat: 11.2, lng: 77.1 })),
  ]);
  assert.deepEqual([r1.status, r2.status].sort(), [201, 409]);
});

test('a rejected site frees its spot', async () => {
  const a = await scout('9811100040');
  const b = await scout('9811100041');
  const adm = await admin();
  const r = await a.post('/api/sites', siteBody({ lat: 11.3, lng: 77.2 }));
  assert.equal((await adm.post(`/api/admin/sites/${r.json.site.code}/reject`, { reason: 'Photo is unclear' })).status, 200);
  assert.equal((await b.post('/api/sites', siteBody({ lat: 11.3, lng: 77.2 }))).status, 201);
});

test('typed locations and weak GPS are refused', async () => {
  const a = await scout('9811100050');
  const typed = await a.post('/api/sites', siteBody({ lat: 11.4, lng: 77.3, gpsSrc: 'manual' }));
  assert.equal(typed.status, 400);
  const weak = await a.post('/api/sites', siteBody({ lat: 11.41, lng: 77.3, acc: 400 }));
  assert.equal(weak.status, 400);
  assert.match(weak.json.error, /too weak/);
});

test('form checks: photo, owner, consent, bad phone', async () => {
  const a = await scout('9811100060');
  const p = (o) => a.post('/api/sites', siteBody({ lat: 11.5, lng: 77.4, ...o }));
  assert.equal((await p({ photo: 'data:text/plain;base64,aGk=' })).status, 400);
  assert.equal((await p({ owner: { name: '', phone: '' } })).status, 400);
  assert.equal((await p({ ownerNotified: false })).status, 400);
  assert.equal((await p({ owner: { name: 'Ok', phone: '123' } })).status, 400);
  assert.equal((await p({ type: 'Residential', sub: 'Hotel / restaurant' })).status, 400);
  assert.equal((await p({ stage: 9 })).status, 400);
  assert.equal((await p({})).status, 201);
});

test('approval pays the flat reward once and nothing else', async () => {
  const a = await scout('9811100070');
  const adm = await admin();
  const r = await a.post('/api/sites', siteBody({ lat: 11.6, lng: 77.5 }));
  const code = r.json.site.code;
  assert.equal((await a.get('/api/wallet')).json.balance, 0);
  assert.equal((await adm.post(`/api/admin/sites/${code}/approve`)).status, 200);
  assert.equal((await adm.post(`/api/admin/sites/${code}/approve`)).status, 409);
  assert.equal((await a.get('/api/wallet')).json.balance, 150);
  // a stage update pays nothing
  assert.equal((await a.post(`/api/sites/${code}/stage`, { stage: 4 })).status, 200);
  assert.equal((await a.post(`/api/sites/${code}/stage`, { stage: 4 })).status, 400);
  assert.equal((await a.get('/api/wallet')).json.balance, 150);
});

test('leads: hidden details, stage windows, credit, buyer limit, privacy', async () => {
  const a = await scout('9811100080');
  const adm = await admin();
  const site = (await a.post('/api/sites', siteBody({ lat: 11.7, lng: 77.6, stage: 1 }))).json.site;
  const sup1 = await supplier('9811100081');
  const sup2 = await supplier('9811100082');
  const sup3 = await supplier('9811100083');
  const sup4 = await supplier('9811100084');

  // not verified: no lead
  assert.equal((await sup1.get('/api/leads')).json.leads.filter((l) => l.siteCode === site.code).length, 0);
  assert.equal((await sup1.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })).status, 404);
  await verify(adm, site.code);

  // stage 1: steel opens at 2, so it is only "coming up"
  const open1 = (await sup1.get('/api/leads')).json.leads.filter((l) => l.siteCode === site.code);
  assert.equal(open1.length, 0);
  const soon = (await sup1.get('/api/leads?state=soon')).json.leads.filter((l) => l.siteCode === site.code);
  assert.ok(soon.some((l) => l.tradeId === 'steel'));
  assert.equal((await sup1.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })).status, 409);

  await a.post(`/api/sites/${site.code}/stage`, { stage: 3 });
  const cards = (await sup1.get('/api/leads')).json.leads.filter((l) => l.siteCode === site.code);
  assert.ok(cards.some((l) => l.tradeId === 'steel') && cards.some((l) => l.tradeId === 'cement'));
  const raw = JSON.stringify(cards);
  assert.ok(!raw.includes('Owner One') && !raw.includes('9000012345') && !raw.includes('11.7'), 'cards hide owner, phone, location');
  assert.equal(cards.find((l) => l.tradeId === 'steel').price, 300);

  // no credit yet
  const poor = await sup1.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' });
  assert.equal(poor.status, 402);
  // photo is private until unlocked
  const photoUrl = site.photo;
  assert.equal((await sup1.get(photoUrl)).status, 404);

  for (const sup of [sup1, sup2, sup3, sup4]) await sup.post('/api/wallet/topup', { amount: 1000 });
  const ok = await sup1.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.balance, 700);
  assert.equal((await sup1.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })).status, 409, 'cannot buy twice');
  const un = (await sup1.get('/api/unlocked')).json.unlocked;
  assert.equal(un[0].site.owner.phone, '9000012345');
  assert.equal((await sup1.get(photoUrl)).status, 200);
  assert.equal((await sup2.get(photoUrl)).status, 404);
  assert.equal((await a.get(photoUrl)).status, 200);
  // the scout earns nothing from the sale
  assert.equal((await a.get('/api/wallet')).json.balance, 150);

  assert.equal((await sup2.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })).status, 200);
  assert.equal((await sup3.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })).status, 200);
  const full = await sup4.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' });
  assert.equal(full.status, 409);
  assert.equal((await sup4.get('/api/wallet')).json.balance, 1000, 'no charge when full');

  // a trade the supplier does not sell
  const tilesOnly = await supplier('9811100085', ['tiles']);
  await tilesOnly.post('/api/wallet/topup', { amount: 500 });
  assert.equal((await tilesOnly.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })).status, 403);
});

test('five suppliers racing for the last slots never oversell', async () => {
  const a = await scout('9811100090');
  const adm = await admin();
  const site = (await a.post('/api/sites', siteBody({ lat: 11.8, lng: 77.7, stage: 3 }))).json.site;
  await verify(adm, site.code);
  const sups = [];
  for (let i = 0; i < 6; i++) { const c = await supplier('98111001' + String(10 + i), ['steel']); await c.post('/api/wallet/topup', { amount: 500 }); sups.push(c); }
  const rs = await Promise.all(sups.map((c) => c.post('/api/leads/unlock', { siteCode: site.code, tradeId: 'steel' })));
  assert.equal(rs.filter((r) => r.status === 200).length, 3);
  const charged = (await Promise.all(sups.map((c) => c.get('/api/wallet')))).filter((r) => r.json.balance === 200).length;
  assert.equal(charged, 3);
});

test('commercial leads cost 1.5 times', async () => {
  const a = await scout('9811100100');
  const adm = await admin();
  const site = (await a.post('/api/sites', siteBody({ lat: 11.9, lng: 77.8, stage: 5, type: 'Commercial', sub: 'Shop / showroom' }))).json.site;
  await verify(adm, site.code);
  const su = await supplier('9811100101', ['tiles']);
  const card = (await su.get('/api/leads')).json.leads.find((l) => l.siteCode === site.code);
  assert.equal(card.price, 300);
});

test('payouts hold money, reject returns it, paid stays', async () => {
  const a = await scout('9811100210');
  const adm = await admin();
  const site = (await a.post('/api/sites', siteBody({ lat: 12.0, lng: 77.9 }))).json.site;
  await verify(adm, site.code);
  assert.equal((await a.post('/api/payouts', { upi: 'bad', amount: 100 })).status, 400);
  assert.equal((await a.post('/api/payouts', { upi: 'asha@okbank', amount: 50 })).status, 400, 'below minimum');
  assert.equal((await a.post('/api/payouts', { upi: 'asha@okbank', amount: 500 })).status, 400, 'above balance');
  assert.equal((await a.post('/api/payouts', { upi: 'asha@okbank', amount: 100 })).json.balance, 50);
  assert.equal((await a.post('/api/payouts', { upi: 'asha@okbank', amount: 100 })).status, 400, 'money is held');
  const list = (await adm.get('/api/admin/payouts')).json.payouts;
  const p = list.find((x) => x.upi === 'asha@okbank');
  assert.equal((await adm.post(`/api/admin/payouts/${p.id}/reject`)).status, 200);
  assert.equal((await a.get('/api/wallet')).json.balance, 150);
  assert.equal((await adm.post(`/api/admin/payouts/${p.id}/paid`)).status, 409);
  await a.post('/api/payouts', { upi: 'asha@okbank', amount: 150 });
  const p2 = (await adm.get('/api/admin/payouts')).json.payouts.find((x) => x.status === 'requested' && x.amount === 150);
  assert.equal((await adm.post(`/api/admin/payouts/${p2.id}/paid`)).status, 200);
  assert.equal((await a.get('/api/wallet')).json.balance, 0);
});

test('admin settings are checked and take effect', async () => {
  const adm = await admin();
  assert.equal((await adm.put('/api/admin/settings', { radius: 1 })).status, 400);
  assert.equal((await adm.put('/api/admin/settings', { maxBuyers: 2 })).json.settings.maxBuyers, 2);
  await adm.put('/api/admin/settings', { maxBuyers: 3 });
  const ins = (await adm.get('/api/admin/insights')).json;
  assert.ok(ins.reported > 0 && Array.isArray(ins.byStage));
});

test('paused users are signed out', async () => {
  const adm = await admin();
  const c = client(s.base);
  const u = await c.signup('9811100120', { role: 'scout' });
  assert.equal((await c.get('/api/me')).json.user.id, u.id);
  assert.equal((await adm.post(`/api/admin/users/${u.id}/status`, { status: 'suspended' })).status, 200);
  assert.equal((await c.get('/api/me')).json.user, null);
  assert.equal((await adm.post(`/api/admin/users/${u.id}/status`, { status: 'active' })).status, 200);
});

test('posting without JSON is refused and static app loads', async () => {
  const res = await fetch(s.base + '/api/auth/logout', { method: 'POST', headers: { 'content-type': 'text/plain' }, body: 'x' });
  assert.equal(res.status, 415);
  const home = await fetch(s.base + '/');
  assert.equal(home.status, 200);
});

test('admin sign-in needs the passcode when one is set', async () => {
  const t = await startServer({ adminPasscode: 'long-secret-123' });
  try {
    const c = client(t.base);
    const a = await c.post('/api/auth/request', { phone: '9000000001' });
    const no = await c.post('/api/auth/verify', { phone: '9000000001', code: a.json.demoCode, name: 'Boss' });
    assert.equal(no.status, 403);
    const bad = await c.post('/api/auth/verify', { phone: '9000000001', code: a.json.demoCode, name: 'Boss', adminPasscode: 'nope' });
    assert.equal(bad.status, 403);
    const yes = await c.post('/api/auth/verify', { phone: '9000000001', code: a.json.demoCode, name: 'Boss', adminPasscode: 'long-secret-123' });
    assert.equal(yes.status, 200);
    assert.equal(yes.json.user.role, 'admin');
    // ordinary users are not asked for it
    const u = client(t.base);
    assert.equal((await u.signup('9811100300', { role: 'scout' })).role, 'scout');
  } finally { t.close(); }
});
