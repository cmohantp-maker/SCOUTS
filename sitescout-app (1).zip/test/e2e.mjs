// Full walk-through in a real headless browser against a real server and database.
// Run: node test/e2e.mjs   (needs Chromium; set CHROME=/path/to/chrome if it is not in the default place)
import { chromium } from 'playwright-core';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const PORT = 3111;
const BASE = `http://127.0.0.1:${PORT}`;
const CHROME = process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const PHOTO = process.env.PHOTO || '/tmp/site.jpg';
const SHOTS = process.env.SHOTS || '/tmp/e2e';
fs.mkdirSync(SHOTS, { recursive: true });

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ss-e2e-'));
const server = spawn('node', ['--disable-warning=ExperimentalWarning', 'src/server.js'], {
  env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir, OTP_MODE: 'demo', PAYMENTS_MODE: 'demo', ADMIN_PHONES: '9000000001', ADMIN_PASSCODE: 'e2e-secret', ALLOW_MANUAL_GPS: 'false' },
  stdio: ['ignore', 'pipe', 'pipe'],
});
server.stderr.on('data', (d) => process.stderr.write(d));
await new Promise((resolve, reject) => {
  const t = setTimeout(() => reject(new Error('server did not start')), 10000);
  server.stdout.on('data', (d) => { if (String(d).includes('running')) { clearTimeout(t); resolve(); } });
});

const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
const problems = [];
const steps = [];
const ok = (m) => { steps.push(m); console.log('ok  ' + m); };

async function person(name, geo) {
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    deviceScaleFactor: 2,
    ...(geo ? { permissions: ['geolocation'], geolocation: geo } : {}),
  });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) problems.push(`${name}: ${m.type()}: ${m.text()}`); });
  page.on('pageerror', (e) => problems.push(`${name}: pageerror: ${e.message}`));
  await page.goto(BASE);
  return { ctx, page, name };
}
async function signup(p, phone, who, opts = {}) {
  const { page } = p;
  await page.fill('#f_auth_phone', phone);
  await page.click('button[data-act=auth-request]');
  await page.waitForSelector('.codebox');
  await page.fill('#f_auth_name', who);
  if (opts.supplier) {
    await page.click('button[data-act=auth-kind][data-v="Material supplier"]');
    for (const t of opts.trades) await page.click(`button[data-act=auth-trade][data-v=${t}]`);
  }
  await page.screenshot({ path: `${SHOTS}/${p.name}-1-signup.png` });
  await page.click('button[data-act=auth-verify]');
  await page.waitForSelector('nav.tabs');
}
const text = (page) => page.locator('body').innerText();

try {
  // ---- Scout A reports a site ----
  const A = await person('scoutA', { latitude: 11.0168, longitude: 76.9558, accuracy: 10 });
  await signup(A, '9811100001', 'Asha Scout');
  ok('scout A signed up with a test code');
  await A.page.click('button[data-act=locate]');
  await A.page.waitForSelector('.banner.ok:has-text("New site")');
  ok('location captured and the server says the spot is new');
  await A.page.setInputFiles('#photoIn', PHOTO);
  await A.page.waitForSelector('.shot img');
  await A.page.fill('#f_draft_locality', 'RS Puram');
  await A.page.fill('#f_draft_name', 'Gandhi Road villa');
  await A.page.selectOption('#f_draft_stage', '3');
  await A.page.fill('#f_draft_owner', 'Mr Raman');
  await A.page.fill('#f_draft_ownerPhone', '98765 43210');
  await A.page.fill('#f_draft_builder', 'Annai Builders');
  await A.page.check('#notified');
  await A.page.screenshot({ path: `${SHOTS}/scoutA-2-report.png`, fullPage: true });
  await A.page.click('button[data-act=submit]');
  await A.page.waitForSelector('text=SS-0001');
  assert.match(await text(A.page), /Awaiting review/);
  ok('site SS-0001 submitted and waiting for review');
  await A.page.screenshot({ path: `${SHOTS}/scoutA-3-mysites.png` });

  // ---- Scout B tries the same spot ----
  const B = await person('scoutB', { latitude: 11.01683, longitude: 76.95581, accuracy: 12 });
  await signup(B, '9811100002', 'Bala Scout');
  await B.page.click('button[data-act=locate]');
  await B.page.waitForSelector('.banner.bad:has-text("already reported")');
  assert.equal(await B.page.getAttribute('button[data-act=submit]', 'aria-disabled'), 'true');
  assert.doesNotMatch(await text(B.page), /SS-0001/, 'the other site code is not shown');
  await B.page.screenshot({ path: `${SHOTS}/scoutB-1-duplicate.png` });
  ok('scout B is blocked from reporting the same site');

  // ---- Admin approves ----
  const M = await person('admin', null);
  await M.page.fill('#f_auth_phone', '9000000001');
  await M.page.click('button[data-act=auth-request]');
  await M.page.waitForSelector('.codebox');
  await M.page.fill('#f_auth_name', 'Admin User');
  await M.page.click('button[data-act=auth-verify]');
  await M.page.waitForSelector('.toast.show:has-text("passcode")');
  ok('admin sign-in is refused without the passcode');
  await M.page.click('summary:has-text("Admin sign-in")');
  await M.page.fill('#f_auth_pass', 'e2e-secret');
  await M.page.click('button[data-act=auth-verify]');
  await M.page.waitForSelector('nav.tabs');
  await M.page.waitForSelector('text=SS-0001');
  assert.match(await text(M.page), /Mr Raman/);
  await M.page.screenshot({ path: `${SHOTS}/admin-1-review.png`, fullPage: true });
  await M.page.click('button[data-act=approve]');
  await M.page.waitForSelector('text=Nothing waiting');
  ok('admin approved SS-0001');
  await M.page.click('button[data-act=tab][data-v=insights]');
  await M.page.waitForSelector('.stats');
  await M.page.screenshot({ path: `${SHOTS}/admin-2-insights.png`, fullPage: true });

  // ---- Supplier buys the steel lead ----
  const U = await person('supplier', null);
  await signup(U, '9811100003', 'Kovai Steel', { supplier: true, trades: ['steel', 'cement'] });
  await U.page.waitForSelector('.item:has-text("Steel")');
  const leadText = await text(U.page);
  assert.doesNotMatch(leadText, /Mr Raman|98765/, 'owner details hidden before unlock');
  await U.page.screenshot({ path: `${SHOTS}/supplier-1-leads.png`, fullPage: true });
  await U.page.click('button[data-act=unlock][data-t=steel]');
  await U.page.waitForSelector('.bal');
  ok('unlock without credit sends the supplier to the wallet');
  await U.page.click('button[data-act=topup][data-v="1000"]');
  await U.page.waitForSelector('.bal:has-text("1,000")');
  await U.page.click('button[data-act=tab][data-v=leads]');
  await U.page.waitForSelector('button[data-act=unlock][data-t=steel]');
  await U.page.click('button[data-act=unlock][data-t=steel]');
  await U.page.waitForSelector('.toast.show:has-text("Unlocked")');
  await U.page.click('button[data-act=tab][data-v=unlocked]');
  await U.page.waitForSelector('text=Mr Raman');
  assert.match(await text(U.page), /98765 43210/);
  let loaded = false;
  for (let i = 0; i < 40 && !loaded; i++) {
    loaded = await U.page.locator('img.photo').first().evaluate((i) => i.complete && i.naturalWidth > 0).catch(() => false);
    if (!loaded) await U.page.waitForTimeout(250);
  }
  assert.ok(loaded, 'photo loads for the supplier who unlocked');
  ok('supplier unlocked the lead and now sees owner contact and photo');
  await U.page.screenshot({ path: `${SHOTS}/supplier-2-unlocked.png`, fullPage: true });

  // ---- Scout A is paid the flat reward ----
  await A.page.click('button[data-act=tab][data-v=wallet]');
  await A.page.waitForSelector('.bal:has-text("150")');
  ok('scout A wallet shows the flat reward');
  await A.page.fill('#f_wd_upi', 'asha@okbank');
  await A.page.fill('#f_wd_amt', '100');
  await A.page.click('button[data-act=payout]');
  await A.page.waitForSelector('.badge:has-text("Requested")');
  await A.page.screenshot({ path: `${SHOTS}/scoutA-4-wallet.png`, fullPage: true });
  await M.page.click('button[data-act=tab][data-v=payouts]');
  await M.page.waitForSelector('button[data-act=payout-paid]');
  await M.page.click('button[data-act=payout-paid]');
  await M.page.waitForSelector('.badge:has-text("Paid")');
  ok('payout requested by scout and marked paid by admin');

  // ---- Reload keeps the session; installable pieces are served ----
  await A.page.reload();
  await A.page.waitForSelector('nav.tabs');
  const mf = await (await fetch(BASE + '/manifest.webmanifest')).json();
  assert.equal(mf.display, 'standalone');
  assert.equal((await fetch(BASE + '/sw.js')).status, 200);
  ok('session survives reload; manifest and service worker are served');
} catch (e) {
  console.error('FAILED:', e.message);
  process.exitCode = 1;
} finally {
  await browser.close();
  server.kill();
}
const real = problems.filter((p) => !/Failed to load resource.*(409|402)|status of 40[239]/.test(p) && !/fonts\.(googleapis|gstatic)|ERR_TUNNEL_CONNECTION_FAILED/.test(p));
if (real.length) { console.log('\nBrowser messages:\n' + real.join('\n')); }
console.log(`\n${steps.length} checks passed${process.exitCode ? ', then a failure' : ''}. Screenshots in ${SHOTS}`);
