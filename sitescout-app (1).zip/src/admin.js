import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { HttpError, int } from './http.js';
import { requireRole } from './auth.js';
import { REJECT_REASONS, SETTING_LIMITS, STAGES, TRADES, TYPES } from './config.js';
import { addLedger, audit, getSettings, tx } from './db.js';
import { fullSite } from './sites.js';

export function adminRoutes(ctx) {
  const { db, photoDir } = ctx;
  const r = express.Router();
  r.use('/admin', requireRole('admin'));

  const nameOf = db.prepare('SELECT name, kind, phone FROM users WHERE id = ?');

  r.get('/admin/sites', (req, res) => {
    const status = ['pending', 'verified', 'rejected'].includes(req.query.status) ? req.query.status : null;
    const rows = status
      ? db.prepare('SELECT * FROM sites WHERE status = ? ORDER BY created_at ASC').all(status)
      : db.prepare('SELECT * FROM sites ORDER BY created_at DESC LIMIT 300').all();
    res.json({
      sites: rows.map((s) => {
        const u = nameOf.get(s.reporter_id) || {};
        return { ...fullSite(s), reporter: { name: u.name, kind: u.kind, phone: u.phone } };
      }),
    });
  });

  r.post('/admin/sites/:code/approve', (req, res) => {
    const site = tx(db, () => {
      const s = db.prepare('SELECT * FROM sites WHERE code = ?').get(req.params.code);
      if (!s) throw new HttpError(404, 'Site not found.');
      if (s.status !== 'pending') throw new HttpError(409, 'This site was already checked.');
      const reward = getSettings(db).reward;
      db.prepare("UPDATE sites SET status = 'verified', verified_at = ?, reject_reason = '' WHERE id = ?").run(Date.now(), s.id);
      if (reward > 0) addLedger(db, s.reporter_id, 'reward', reward, `Site verified, ${s.code}`, s.id);
      audit(db, req.user.id, 'approve', s.code);
      return db.prepare('SELECT * FROM sites WHERE id = ?').get(s.id);
    });
    res.json({ site: fullSite(site) });
  });

  r.post('/admin/sites/:code/reject', (req, res) => {
    const reason = REJECT_REASONS.includes(req.body.reason) ? req.body.reason : 'Other';
    const site = tx(db, () => {
      const s = db.prepare('SELECT * FROM sites WHERE code = ?').get(req.params.code);
      if (!s) throw new HttpError(404, 'Site not found.');
      if (s.status !== 'pending') throw new HttpError(409, 'This site was already checked.');
      db.prepare("UPDATE sites SET status = 'rejected', reject_reason = ? WHERE id = ?").run(reason, s.id);
      audit(db, req.user.id, 'reject', `${s.code}: ${reason}`);
      return db.prepare('SELECT * FROM sites WHERE id = ?').get(s.id);
    });
    res.json({ site: fullSite(site) });
  });

  r.get('/admin/payouts', (_req, res) => {
    const rows = db.prepare('SELECT * FROM payouts ORDER BY CASE status WHEN \'requested\' THEN 0 ELSE 1 END, ts DESC LIMIT 200').all();
    res.json({
      payouts: rows.map((p) => ({ ...p, user: nameOf.get(p.user_id) || {} })),
    });
  });

  r.post('/admin/payouts/:id/paid', (req, res) => {
    tx(db, () => {
      const p = db.prepare('SELECT * FROM payouts WHERE id = ?').get(Number(req.params.id));
      if (!p) throw new HttpError(404, 'Payout not found.');
      if (p.status !== 'requested') throw new HttpError(409, 'This payout was already handled.');
      db.prepare("UPDATE payouts SET status = 'paid', done_at = ? WHERE id = ?").run(Date.now(), p.id);
      audit(db, req.user.id, 'payout-paid', `${p.id}: ₹${p.amount} to ${p.upi}`);
    });
    res.json({ ok: true });
  });

  // A rejected payout gives the money back to the scout.
  r.post('/admin/payouts/:id/reject', (req, res) => {
    tx(db, () => {
      const p = db.prepare('SELECT * FROM payouts WHERE id = ?').get(Number(req.params.id));
      if (!p) throw new HttpError(404, 'Payout not found.');
      if (p.status !== 'requested') throw new HttpError(409, 'This payout was already handled.');
      db.prepare("UPDATE payouts SET status = 'rejected', done_at = ? WHERE id = ?").run(Date.now(), p.id);
      addLedger(db, p.user_id, 'refund', p.amount, `Payout ${p.id} returned to your balance`);
      audit(db, req.user.id, 'payout-rejected', `${p.id}`);
    });
    res.json({ ok: true });
  });

  r.get('/admin/insights', (_req, res) => {
    const one = (sql, ...a) => db.prepare(sql).get(...a);
    const count = (status) => one('SELECT COUNT(*) AS n FROM sites WHERE status = ?', status).n;
    const verified = db.prepare("SELECT stage, type FROM sites WHERE status = 'verified'").all();
    const byStage = STAGES.map((s) => ({ name: `${s.n}. ${s.name}`, n: verified.filter((v) => v.stage === s.n).length }));
    const byType = Object.keys(TYPES).map((t) => ({ name: t, n: verified.filter((v) => v.type === t).length }));
    const sold = Object.fromEntries(db.prepare('SELECT trade_id, COUNT(*) AS n FROM unlocks GROUP BY trade_id').all().map((x) => [x.trade_id, x.n]));
    const openNow = db.prepare("SELECT stage FROM sites WHERE status = 'verified'").all();
    const byTrade = TRADES.map((t) => ({
      name: t.name,
      open: openNow.filter((s) => s.stage >= t.from && s.stage <= t.to).length,
      sold: sold[t.id] || 0,
    }));
    res.json({
      reported: one('SELECT COUNT(*) AS n FROM sites').n,
      verified: count('verified'),
      pending: count('pending'),
      rejected: count('rejected'),
      leadsSold: one('SELECT COUNT(*) AS n FROM unlocks').n,
      revenue: one('SELECT COALESCE(SUM(price),0) AS n FROM unlocks').n,
      rewardsPaid: one("SELECT COALESCE(SUM(amount),0) AS n FROM ledger WHERE type = 'reward'").n,
      users: {
        scouts: one("SELECT COUNT(*) AS n FROM users WHERE role = 'scout'").n,
        suppliers: one("SELECT COUNT(*) AS n FROM users WHERE role = 'supplier'").n,
      },
      byStage,
      byType,
      byTrade,
    });
  });

  r.get('/admin/settings', (_req, res) => res.json({ settings: getSettings(db), limits: SETTING_LIMITS }));

  r.put('/admin/settings', (req, res) => {
    const next = {};
    for (const [k, [min, max]] of Object.entries(SETTING_LIMITS)) {
      if (req.body[k] !== undefined) next[k] = int(req.body[k], k, { min, max });
    }
    tx(db, () => {
      const up = db.prepare('UPDATE settings SET value = ? WHERE key = ?');
      for (const [k, v] of Object.entries(next)) up.run(v, k);
      audit(db, req.user.id, 'settings', JSON.stringify(next));
    });
    res.json({ settings: getSettings(db) });
  });

  r.get('/admin/users', (_req, res) => {
    const rows = db.prepare('SELECT id, name, phone, role, kind, status, created_at FROM users ORDER BY created_at DESC LIMIT 500').all();
    const rep = Object.fromEntries(db.prepare('SELECT reporter_id AS id, COUNT(*) AS n, SUM(status = \'verified\') AS ok, SUM(status = \'rejected\') AS bad FROM sites GROUP BY reporter_id').all().map((x) => [x.id, x]));
    res.json({
      users: rows.map((u) => ({ ...u, reports: rep[u.id]?.n || 0, verified: rep[u.id]?.ok || 0, rejected: rep[u.id]?.bad || 0 })),
    });
  });

  r.post('/admin/users/:id/status', (req, res) => {
    const status = req.body.status === 'suspended' ? 'suspended' : 'active';
    const id = Number(req.params.id);
    if (id === req.user.id) throw new HttpError(400, 'You cannot pause your own account.');
    const info = db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, id);
    if (!info.changes) throw new HttpError(404, 'User not found.');
    if (status === 'suspended') db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
    audit(db, req.user.id, 'user-' + status, String(id));
    res.json({ ok: true });
  });

  return r;
}
