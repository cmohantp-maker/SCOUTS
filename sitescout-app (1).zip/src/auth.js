import crypto from 'node:crypto';
import express from 'express';
import { HttpError, sha256, parseCookies, rateLimiter, ipKey } from './http.js';
import { SCOUT_KINDS, TRADES } from './config.js';
import { digits10, validIndianMobile, clean } from './logic.js';

function sameSecret(a, b) {
  return crypto.timingSafeEqual(Buffer.from(sha256(a), 'hex'), Buffer.from(sha256(b), 'hex'));
}
import { audit } from './db.js';

const SESSION_MS = 30 * 24 * 3600 * 1000;
const OTP_MS = 5 * 60 * 1000;
const COOKIE = 'sid';

export const publicUser = (u) => ({
  id: u.id,
  name: u.name,
  role: u.role,
  kind: u.kind,
  phone: u.phone,
  trades: JSON.parse(u.trades || '[]'),
  upi: u.upi,
});

export function authMiddleware(ctx) {
  const { db } = ctx;
  return (req, _res, next) => {
    const token = parseCookies(req.headers.cookie)[COOKIE];
    req.user = null;
    if (token) {
      const row = db
        .prepare(
          `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
           WHERE s.token_hash = ? AND s.expires_at > ?`,
        )
        .get(sha256(token), Date.now());
      if (row && row.status === 'active') req.user = row;
    }
    next();
  };
}

export const requireRole =
  (...roles) =>
  (req, _res, next) => {
    if (!req.user) return next(new HttpError(401, 'Please sign in.'));
    if (!roles.includes(req.user.role)) return next(new HttpError(403, 'This is not available for your account.'));
    next();
  };

function setSessionCookie(ctx, res, token) {
  const parts = [`${COOKIE}=${token}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${SESSION_MS / 1000}`];
  if (ctx.env.production) parts.push('Secure');
  res.setHeader('Set-Cookie', parts.join('; '));
}

export function authRoutes(ctx) {
  const { db, env } = ctx;
  const r = express.Router();
  const reqLimit = rateLimiter({ windowMs: 10 * 60 * 1000, max: env.authRateLimit ?? 10, key: ipKey });
  const verifyLimit = rateLimiter({ windowMs: 10 * 60 * 1000, max: (env.authRateLimit ?? 10) * 3, key: ipKey });

  r.get('/me', (req, res) => {
    res.json({ user: req.user ? publicUser(req.user) : null });
  });

  // Step 1: ask for a code. In demo mode the code comes back in the response.
  r.post('/auth/request', reqLimit, (req, res) => {
    const raw = String(req.body.phone || '');
    if (!validIndianMobile(raw)) throw new HttpError(400, 'Enter a 10-digit mobile number.');
    const phone = digits10(raw);
    const old = db.prepare('SELECT sent_at FROM otps WHERE phone = ?').get(phone);
    if (old && Date.now() - old.sent_at < 15000) throw new HttpError(429, 'Wait a few seconds before asking for another code.');
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    db.prepare(
      `INSERT INTO otps (phone, code_hash, expires_at, attempts, sent_at) VALUES (?,?,?,0,?)
       ON CONFLICT(phone) DO UPDATE SET code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0, sent_at = excluded.sent_at`,
    ).run(phone, sha256(phone + ':' + code), Date.now() + OTP_MS, Date.now());
    const exists = !!db.prepare('SELECT 1 FROM users WHERE phone = ?').get(phone);
    const out = { ok: true, exists };
    if (env.otpMode === 'demo') out.demoCode = code;
    // A real SMS provider would be called here when OTP_MODE is not "demo".
    else throw new HttpError(501, 'SMS login is not set up on this server yet.');
    res.json(out);
  });

  // Step 2: check the code. New numbers also send name and role.
  r.post('/auth/verify', verifyLimit, (req, res) => {
    const phone = digits10(req.body.phone);
    const code = String(req.body.code || '').replace(/\D/g, '');
    const row = db.prepare('SELECT * FROM otps WHERE phone = ?').get(phone);
    if (!row || row.expires_at < Date.now()) throw new HttpError(400, 'That code has expired. Ask for a new one.');
    if (row.attempts >= 5) throw new HttpError(429, 'Too many wrong codes. Ask for a new one.');
    if (sha256(phone + ':' + code) !== row.code_hash) {
      db.prepare('UPDATE otps SET attempts = attempts + 1 WHERE phone = ?').run(phone);
      throw new HttpError(400, 'That code is not right.');
    }

    let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
    const isAdminPhone = env.adminPhones.includes(phone);
    if ((isAdminPhone || user?.role === 'admin') && env.adminPasscode) {
      if (!sameSecret(String(req.body.adminPasscode || ''), env.adminPasscode)) {
        db.prepare('UPDATE otps SET attempts = attempts + 1 WHERE phone = ?').run(phone);
        throw new HttpError(403, 'Admin sign-in needs the admin passcode.');
      }
    }
    if (!user) {
      const name = clean(req.body.name, 60);
      if (name.length < 2) throw new HttpError(400, 'Enter your name.');
      let role = req.body.role === 'supplier' ? 'supplier' : 'scout';
      let kind;
      let trades = [];
      if (role === 'supplier') {
        kind = 'Material supplier';
        const ids = Array.isArray(req.body.trades) ? req.body.trades : [];
        trades = [...new Set(ids.filter((t) => TRADES.some((x) => x.id === t)))];
        if (!trades.length) throw new HttpError(400, 'Pick at least one trade you sell.');
      } else {
        kind = SCOUT_KINDS.includes(req.body.kind) ? req.body.kind : 'Public member';
      }
      if (isAdminPhone) {
        role = 'admin';
        kind = 'Admin';
        trades = [];
      }
      const info = db
        .prepare('INSERT INTO users (phone, name, role, kind, trades, created_at) VALUES (?,?,?,?,?,?)')
        .run(phone, name, role, kind, JSON.stringify(trades), Date.now());
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
      audit(db, user.id, 'signup', role);
    } else if (isAdminPhone && user.role !== 'admin') {
      db.prepare("UPDATE users SET role = 'admin', kind = 'Admin' WHERE id = ?").run(user.id);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
    }
    if (user.status !== 'active') throw new HttpError(403, 'This account is paused. Contact the admin.');

    db.prepare('DELETE FROM otps WHERE phone = ?').run(phone);
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)').run(
      sha256(token),
      user.id,
      Date.now(),
      Date.now() + SESSION_MS,
    );
    setSessionCookie(ctx, res, token);
    res.json({ user: publicUser(user) });
  });

  r.post('/auth/logout', (req, res) => {
    const token = parseCookies(req.headers.cookie)[COOKIE];
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
    res.json({ ok: true });
  });

  return r;
}
