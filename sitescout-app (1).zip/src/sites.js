import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import express from 'express';
import { HttpError, int } from './http.js';
import { requireRole } from './auth.js';
import { BUDGETS, STAGES, TRADES, TYPES } from './config.js';
import { boundingBox, clean, digits10, distanceMeters, leadPrice, quality, tradeState } from './logic.js';
import { getSettings, nextSiteCode, tx } from './db.js';

const MAX_PHOTO_BYTES = 1_500_000;
const MAX_PENDING_PER_SCOUT = 20;

// Everything about a site, for the person who reported it, suppliers who unlocked it, and admins.
export function fullSite(s) {
  return {
    code: s.code,
    name: s.name,
    locality: s.locality,
    lat: s.lat,
    lng: s.lng,
    acc: s.acc,
    gpsSrc: s.gps_src,
    type: s.type,
    sub: s.sub,
    stage: s.stage,
    area: s.area,
    budget: s.budget,
    owner: { name: s.owner_name, phone: s.owner_phone },
    architect: { name: s.arch_name, phone: s.arch_phone },
    engineer: { name: s.eng_name, phone: s.eng_phone },
    builder: { name: s.builder_name, phone: s.builder_phone },
    ownerNotified: !!s.owner_notified,
    photo: s.photo ? '/api/photo/' + s.photo : '',
    status: s.status,
    rejectReason: s.reject_reason,
    flags: JSON.parse(s.flags || '[]'),
    quality: quality(s),
    createdAt: s.created_at,
    verifiedAt: s.verified_at,
  };
}

export function parsePhoto(dataUrl) {
  const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw new HttpError(400, 'Take a site photo first.');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length < 500 || buf.length > MAX_PHOTO_BYTES) throw new HttpError(400, 'The photo is too large. Retake it.');
  const jpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const png = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  const webp = buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP';
  if (!(jpeg || png || webp)) throw new HttpError(400, 'That file is not a photo.');
  return { buf, ext: jpeg ? 'jpg' : png ? 'png' : 'webp' };
}

// Finds the closest live (pending or verified) site within the radius. Rejected sites free their spot.
export function findDuplicate(db, lat, lng, radius) {
  const b = boundingBox(lat, lng, radius);
  const rows = db
    .prepare(
      `SELECT code, lat, lng, reporter_id FROM sites
       WHERE status != 'rejected' AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?`,
    )
    .all(b.minLat, b.maxLat, b.minLng, b.maxLng);
  let best = null;
  for (const s of rows) {
    const d = distanceMeters({ lat, lng }, s);
    if (d <= radius && (!best || d < best.distance)) best = { ...s, distance: d };
  }
  return best;
}

function readCoords(body) {
  const lat = Number(body.lat);
  const lng = Number(body.lng);
  if (!(lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) || (lat === 0 && lng === 0)) {
    throw new HttpError(400, 'The location is not valid. Capture it again.');
  }
  return { lat: Math.round(lat * 1e6) / 1e6, lng: Math.round(lng * 1e6) / 1e6 };
}

function person(body, key, { required = false, label } = {}) {
  const p = body[key] || {};
  const name = clean(p.name, 80);
  let phone = clean(p.phone, 20);
  if (required && name.length < 2) throw new HttpError(400, `Enter the ${label || key} name.`);
  if (phone && digits10(phone).length !== 10) throw new HttpError(400, `The ${label || key} phone number needs 10 digits.`);
  if (!name) phone = '';
  return { name, phone };
}

export function siteRoutes(ctx) {
  const { db, env, photoDir } = ctx;
  const r = express.Router();
  const scouts = requireRole('scout');

  // Quick check used by the app as soon as a location is captured.
  r.post('/sites/check', scouts, (req, res) => {
    const { lat, lng } = readCoords(req.body);
    const dup = findDuplicate(db, lat, lng, getSettings(db).radius);
    if (!dup) return res.json({ duplicate: false });
    const own = dup.reporter_id === req.user.id;
    res.json({ duplicate: true, own, code: own ? dup.code : undefined, distance: Math.round(dup.distance) });
  });

  r.post('/sites', scouts, (req, res) => {
    const b = req.body || {};
    const { lat, lng } = readCoords(b);
    const settings = getSettings(db);

    const src = b.gpsSrc === 'manual' ? 'manual' : 'gps';
    if (src === 'manual' && !env.allowManualGps) throw new HttpError(400, 'Typed locations are not accepted. Capture the location with GPS.');
    const acc = Math.max(0, Math.round(Number(b.acc) || 0));
    if (src === 'gps' && acc > settings.maxGpsAccuracy) {
      throw new HttpError(400, `GPS is too weak (±${acc} m). Move to open sky and capture the location again.`);
    }

    const locality = clean(b.locality, 60);
    if (locality.length < 2) throw new HttpError(400, 'Enter the area name.');
    const type = String(b.type);
    if (!TYPES[type] || !TYPES[type].includes(String(b.sub))) throw new HttpError(400, 'Choose the type of project.');
    const stage = int(b.stage, 'Stage', { min: 1, max: STAGES.length });
    const area = b.area ? int(b.area, 'Built-up area', { min: 1, max: 10_000_000 }) : 0;
    const budget = BUDGETS.includes(b.budget) ? b.budget : '';
    const owner = person(b, 'owner', { required: true, label: 'owner' });
    const arch = person(b, 'architect', { label: 'architect' });
    const eng = person(b, 'engineer', { label: 'engineer' });
    const builder = person(b, 'builder', { label: 'builder' });
    if (b.ownerNotified !== true) throw new HttpError(400, 'Confirm that you told the owner about this listing.');
    const photo = parsePhoto(b.photo);

    const created = tx(db, () => {
      const pending = db.prepare("SELECT COUNT(*) AS n FROM sites WHERE reporter_id = ? AND status = 'pending'").get(req.user.id).n;
      if (pending >= MAX_PENDING_PER_SCOUT) throw new HttpError(429, 'You have many reports waiting for review. Wait for the admin to check them.');

      const dup = findDuplicate(db, lat, lng, settings.radius);
      if (dup) {
        const own = dup.reporter_id === req.user.id;
        throw new HttpError(409, own ? `You already reported this site as ${dup.code}.` : 'This site is already reported by another member.', {
          duplicate: true,
          own,
        });
      }

      const flags = [];
      if (src === 'manual') flags.push('Location typed by hand');
      if (src === 'gps' && acc > 50) flags.push(`Weak GPS signal (±${acc} m)`);
      if (owner.phone) {
        const same = db
          .prepare("SELECT code FROM sites WHERE owner_phone = ? AND status != 'rejected' LIMIT 1")
          .get(owner.phone);
        if (same) flags.push(`Owner phone also on ${same.code}`);
      }

      const code = nextSiteCode(db);
      const file = `${code}-${crypto.randomBytes(6).toString('hex')}.${photo.ext}`;
      fs.writeFileSync(path.join(photoDir, file), photo.buf);
      const now = Date.now();
      const info = db
        .prepare(
          `INSERT INTO sites (code, name, locality, lat, lng, acc, gps_src, type, sub, stage, area, budget,
             owner_name, owner_phone, owner_notified, arch_name, arch_phone, eng_name, eng_phone,
             builder_name, builder_phone, photo, flags, reporter_id, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        )
        .run(
          code,
          clean(b.name, 80) || `Site at ${locality}`,
          locality,
          lat,
          lng,
          acc,
          src,
          type,
          b.sub,
          stage,
          area,
          budget,
          owner.name,
          owner.phone,
          1,
          arch.name,
          arch.phone,
          eng.name,
          eng.phone,
          builder.name,
          builder.phone,
          file,
          JSON.stringify(flags),
          req.user.id,
          now,
        );
      db.prepare('INSERT INTO stage_log (site_id, stage, user_id, ts) VALUES (?,?,?,?)').run(info.lastInsertRowid, stage, req.user.id, now);
      return db.prepare('SELECT * FROM sites WHERE id = ?').get(info.lastInsertRowid);
    });
    res.status(201).json({ site: fullSite(created) });
  });

  r.get('/sites/mine', scouts, (req, res) => {
    const rows = db.prepare('SELECT * FROM sites WHERE reporter_id = ? ORDER BY created_at DESC').all(req.user.id);
    const sold = db
      .prepare('SELECT trade_id, COUNT(*) AS n FROM unlocks WHERE site_id = ? GROUP BY trade_id');
    const maxBuyers = getSettings(db).maxBuyers;
    const sites = rows.map((s) => {
      const counts = Object.fromEntries(sold.all(s.id).map((x) => [x.trade_id, x.n]));
      const trades = TRADES.map((t) => ({
        id: t.id,
        name: t.name,
        from: t.from,
        to: t.to,
        state: tradeState(s.stage, t),
        price: leadPrice(s, t),
        sold: counts[t.id] || 0,
        maxBuyers,
      }));
      return { ...fullSite(s), trades };
    });
    res.json({ sites });
  });

  r.post('/sites/:code/stage', scouts, (req, res) => {
    const stage = int(req.body.stage, 'Stage', { min: 1, max: STAGES.length });
    const out = tx(db, () => {
      const s = db.prepare('SELECT * FROM sites WHERE code = ? AND reporter_id = ?').get(req.params.code, req.user.id);
      if (!s) throw new HttpError(404, 'Site not found.');
      if (s.status !== 'verified') throw new HttpError(409, 'Only verified sites can be updated.');
      if (stage <= s.stage) throw new HttpError(400, 'Choose a later stage.');
      db.prepare('UPDATE sites SET stage = ? WHERE id = ?').run(stage, s.id);
      db.prepare('INSERT INTO stage_log (site_id, stage, user_id, ts) VALUES (?,?,?,?)').run(s.id, stage, req.user.id, Date.now());
      return db.prepare('SELECT * FROM sites WHERE id = ?').get(s.id);
    });
    res.json({ site: fullSite(out) });
  });

  // Photos are private: the reporter, admins, and suppliers who unlocked a lead on that site.
  r.get('/photo/:file', (req, res, next) => {
    if (!req.user) return next(new HttpError(401, 'Please sign in.'));
    const file = path.basename(req.params.file);
    const s = db.prepare('SELECT id, reporter_id FROM sites WHERE photo = ?').get(file);
    if (!s) return next(new HttpError(404, 'Not found.'));
    const ok =
      req.user.role === 'admin' ||
      s.reporter_id === req.user.id ||
      !!db.prepare('SELECT 1 FROM unlocks WHERE site_id = ? AND user_id = ?').get(s.id, req.user.id);
    if (!ok) return next(new HttpError(404, 'Not found.'));
    res.setHeader('Cache-Control', 'private, max-age=86400');
    res.sendFile(path.resolve(photoDir, file));
  });

  return r;
}
