import express from 'express';
import { HttpError, int } from './http.js';
import { requireRole } from './auth.js';
import { addLedger, balanceOf, getSettings, tx } from './db.js';
import { validUpi } from './logic.js';

export function walletRoutes(ctx) {
  const { db, env } = ctx;
  const r = express.Router();
  const money = requireRole('scout', 'supplier');

  r.get('/wallet', money, (req, res) => {
    const ledger = db
      .prepare('SELECT id, type, amount, note, ts FROM ledger WHERE user_id = ? ORDER BY ts DESC, id DESC LIMIT 200')
      .all(req.user.id);
    const payouts = db
      .prepare('SELECT id, upi, amount, status, ts, done_at FROM payouts WHERE user_id = ? ORDER BY ts DESC LIMIT 50')
      .all(req.user.id);
    const earned = db
      .prepare("SELECT COALESCE(SUM(amount),0) AS n FROM ledger WHERE user_id = ? AND type = 'reward'")
      .get(req.user.id).n;
    const s = getSettings(db);
    res.json({
      balance: balanceOf(db, req.user.id),
      earned,
      ledger,
      payouts,
      minWithdraw: s.minWithdraw,
      topupEnabled: env.paymentsMode === 'demo' && req.user.role === 'supplier',
    });
  });

  // Demo only: adds credit without taking money. A payment gateway replaces this before launch.
  r.post('/wallet/topup', requireRole('supplier'), (req, res) => {
    if (env.paymentsMode !== 'demo') throw new HttpError(501, 'Online payment is not set up on this server yet.');
    const amount = int(req.body.amount, 'Amount', { min: 100, max: 50000 });
    addLedger(db, req.user.id, 'topup', amount, 'Added credit (demo, no real payment)');
    res.json({ balance: balanceOf(db, req.user.id) });
  });

  // A request holds the money straight away so it cannot be spent twice.
  r.post('/payouts', requireRole('scout'), (req, res) => {
    const upi = String(req.body.upi || '').trim();
    if (!validUpi(upi)) throw new HttpError(400, 'Enter a valid UPI ID, like name@bank.');
    const amount = int(req.body.amount, 'Amount', { min: 1, max: 1_000_000 });
    tx(db, () => {
      const min = getSettings(db).minWithdraw;
      if (amount < min) throw new HttpError(400, `The smallest payout is ₹${min}.`);
      if (amount > balanceOf(db, req.user.id)) throw new HttpError(400, 'That is more than your balance.');
      db.prepare('INSERT INTO payouts (user_id, upi, amount, ts) VALUES (?,?,?,?)').run(req.user.id, upi, amount, Date.now());
      addLedger(db, req.user.id, 'payout', -amount, `Payout requested to ${upi}`);
      db.prepare('UPDATE users SET upi = ? WHERE id = ?').run(upi, req.user.id);
    });
    res.json({ balance: balanceOf(db, req.user.id) });
  });

  return r;
}
