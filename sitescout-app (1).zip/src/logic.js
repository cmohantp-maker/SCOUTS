// Pure rules. No database and no HTTP here, so they are easy to test.
import { TRADES, TYPE_MULT } from './config.js';

export const tradeById = (id) => TRADES.find((t) => t.id === id);

export function distanceMeters(a, b) {
  const R = 6371000;
  const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

// Rough box around a point, used to narrow the database query before the exact distance check.
export function boundingBox(lat, lng, meters) {
  const dLat = meters / 111320;
  const dLng = meters / (111320 * Math.max(0.2, Math.cos((lat * Math.PI) / 180)));
  return { minLat: lat - dLat, maxLat: lat + dLat, minLng: lng - dLng, maxLng: lng + dLng };
}

export const digits10 = (s) => String(s || '').replace(/\D/g, '').slice(-10);

export const validIndianMobile = (s) => /^[6-9]\d{9}$/.test(digits10(s)) && String(s || '').replace(/\D/g, '').length >= 10;

export function leadPrice(site, trade) {
  return Math.round((trade.price * (TYPE_MULT[site.type] || 1)) / 10) * 10;
}

export function tradeState(stage, trade) {
  if (stage < trade.from) return 'upcoming';
  if (stage > trade.to) return 'closed';
  return 'open';
}

// How complete a lead is, out of 100. Suppliers see this before paying.
export function quality(site) {
  let q = 0;
  if (site.photo) q += 20;
  if (site.owner_name) q += 15;
  if (digits10(site.owner_phone).length === 10) q += 15;
  if (site.builder_name) q += 10;
  if (site.arch_name) q += 10;
  if (site.eng_name) q += 10;
  if (site.area) q += 10;
  if (site.budget) q += 10;
  return q;
}

export const validUpi = (s) => /^[\w.\-]{2,64}@[A-Za-z]{2,32}$/.test(String(s || ''));

export function clean(s, max = 120) {
  return String(s == null ? '' : s)
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, max);
}
