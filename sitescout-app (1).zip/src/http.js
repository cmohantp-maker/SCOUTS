import crypto from 'node:crypto';

export class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

export const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

export function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

// Small in-memory limiter. Good enough for one server process.
export function rateLimiter({ windowMs, max, key }) {
  const hits = new Map();
  return (req, _res, next) => {
    const now = Date.now();
    const k = key(req);
    const arr = (hits.get(k) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) return next(new HttpError(429, 'Too many tries. Wait a few minutes and try again.'));
    arr.push(now);
    hits.set(k, arr);
    if (hits.size > 5000) for (const [kk, v] of hits) if (!v.some((t) => now - t < windowMs)) hits.delete(kk);
    next();
  };
}

export const ipKey = (req) => req.ip || req.socket.remoteAddress || 'x';

export function int(v, name, { min = 0, max = 1e9 } = {}) {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(400, `${name} is not valid.`);
  return n;
}
