import path from 'node:path';
import { ENV } from './config.js';
import { openDb } from './db.js';
import { createApp } from './app.js';

const dbFile = path.join(ENV.dataDir, 'sitescout.db');
const db = openDb(dbFile);
const app = createApp({
  db,
  env: ENV,
  photoDir: path.join(ENV.dataDir, 'photos'),
  publicDir: new URL('../public', import.meta.url).pathname,
});

if (ENV.production && ENV.otpMode === 'demo' && ENV.adminPhones.length && !ENV.adminPasscode) {
  console.error('Refusing to start: OTP_MODE=demo shows login codes on screen, so anyone who knows an admin phone number could sign in as admin. Set ADMIN_PASSCODE to a long secret.');
  process.exit(1);
}
if (ENV.production && ENV.otpMode === 'demo') {
  console.warn('WARNING: OTP_MODE=demo shows login codes on screen. Anyone can sign in as anyone. Pilot use only.');
}
if (!ENV.adminPhones.length) console.warn('No ADMIN_PHONES set, so nobody can approve sites. Set ADMIN_PHONES to your 10-digit number.');

app.listen(ENV.port, () => {
  console.log(`SiteScout running on port ${ENV.port}. Data in ${ENV.dataDir}`);
});
