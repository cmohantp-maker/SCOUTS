import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { HttpError } from './http.js';
import { authMiddleware, authRoutes } from './auth.js';
import { siteRoutes } from './sites.js';
import { leadRoutes } from './leads.js';
import { walletRoutes } from './wallet.js';
import { adminRoutes } from './admin.js';
import { BUDGETS, REJECT_REASONS, SCOUT_KINDS, STAGES, TRADES, TYPES } from './config.js';
import { getSettings } from './db.js';

// ctx = { db, env, photoDir, publicDir }
export function createApp(ctx) {
  const { db, env } = ctx;
  fs.mkdirSync(ctx.photoDir, { recursive: true });

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(self), camera=(self), microphone=()');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    );
    next();
  });

  app.use(express.json({ limit: '3mb' }));

  // JSON only: a page on another site cannot send this without a cross-origin check.
  app.use('/api', (req, _res, next) => {
    if (req.method !== 'GET' && !req.is('application/json')) return next(new HttpError(415, 'Send JSON.'));
    next();
  });

  app.use('/api', authMiddleware(ctx));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));

  app.get('/api/config', (_req, res) => {
    res.json({
      stages: STAGES,
      trades: TRADES.map(({ id, name, from, to }) => ({ id, name, from, to })),
      types: TYPES,
      budgets: BUDGETS,
      scoutKinds: SCOUT_KINDS,
      rejectReasons: REJECT_REASONS,
      settings: getSettings(db),
      otpDemo: env.otpMode === 'demo',
      allowManualGps: env.allowManualGps,
    });
  });

  app.use('/api', authRoutes(ctx));
  app.use('/api', siteRoutes(ctx));
  app.use('/api', leadRoutes(ctx));
  app.use('/api', walletRoutes(ctx));
  app.use('/api', adminRoutes(ctx));

  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Not found.')));

  // Static app. The service worker must not be cached for long so updates arrive.
  app.use(
    express.static(ctx.publicDir, {
      setHeaders(res, file) {
        if (file.endsWith('sw.js') || file.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
      },
    }),
  );
  app.get('*', (_req, res) => res.sendFile(path.resolve(ctx.publicDir, 'index.html')));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, ...err.extra });
    if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'The photo is too large. Retake it.' });
    if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Bad request.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server. Try again.' });
  });

  return app;
}
