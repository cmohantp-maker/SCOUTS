import express from 'express';
import { HttpError } from './http.js';
import { requireRole } from './auth.js';
import { TRADES, STAGES } from './config.js';
import { leadPrice, quality, tradeById, tradeState } from './logic.js';
import { addLedger, balanceOf, getSettings, tx } from './db.js';
import { fullSite } from './sites.js';

export function leadRoutes(ctx) {
  const { db } = ctx;
  const r = express.Router();
  const suppliers = requireRole('supplier');

  // Cards shown before paying. They hide the owner, the people and the exact location.
  const card = (s, t, taken, maxBuyers) => ({
    siteCode: s.code,
    tradeId: t.id,
    tradeName: t.name,
    price: leadPrice(s, t),
    type: s.type,
    sub: s.sub,
    locality: s.locality,
    stage: s.stage,
    stageName: STAGES.find((x) => x.n === s.stage).name,
    opensAtStage: t.from,
    opensAtName: STAGES.find((x) => x.n === t.from).name,
    area: s.area,
    budget: s.budget,
    quality: quality(s),
    slotsLeft: Math.max(0, maxBuyers - taken),
    maxBuyers,
    verifiedAt: s.verified_at,
  });

  r.get('/leads', suppliers, (req, res) => {
    const want = req.query.state === 'soon' ? 'upcoming' : 'open';
    const mine = JSON.parse(req.user.trades || '[]');
    const maxBuyers = getSettings(db).maxBuyers;
    const sites = db.prepare("SELECT * FROM sites WHERE status = 'verified'").all();
    const taken = new Map();
    for (const u of db.prepare('SELECT site_id, trade_id, COUNT(*) AS n FROM unlocks GROUP BY site_id, trade_id').all()) {
      taken.set(u.site_id + ':' + u.trade_id, u.n);
    }
    const mineUnlocked = new Set(
      db.prepare('SELECT site_id, trade_id FROM unlocks WHERE user_id = ?').all(req.user.id).map((u) => u.site_id + ':' + u.trade_id),
    );
    const out = [];
    for (const s of sites) {
      for (const t of TRADES) {
        if (!mine.includes(t.id) || tradeState(s.stage, t) !== want) continue;
        if (mineUnlocked.has(s.id + ':' + t.id)) continue;
        out.push(card(s, t, taken.get(s.id + ':' + t.id) || 0, maxBuyers));
      }
    }
    out.sort((a, b) => b.quality - a.quality || b.verifiedAt - a.verifiedAt);
    res.json({ leads: out });
  });

  r.put('/me/trades', suppliers, (req, res) => {
    const ids = Array.isArray(req.body.trades) ? req.body.trades : [];
    const trades = [...new Set(ids.filter((id) => tradeById(id)))];
    if (!trades.length) throw new HttpError(400, 'Pick at least one trade.');
    db.prepare('UPDATE users SET trades = ? WHERE id = ?').run(JSON.stringify(trades), req.user.id);
    res.json({ trades });
  });

  // Buying a lead: every check and write happens in one transaction.
  r.post('/leads/unlock', suppliers, (req, res) => {
    const t = tradeById(String(req.body.tradeId));
    if (!t) throw new HttpError(400, 'Lead not found.');
    const out = tx(db, () => {
      const s = db.prepare('SELECT * FROM sites WHERE code = ?').get(String(req.body.siteCode));
      if (!s || s.status !== 'verified') throw new HttpError(404, 'This lead is not available.');
      if (!JSON.parse(req.user.trades || '[]').includes(t.id)) throw new HttpError(403, 'Add this trade to your list first.');
      if (tradeState(s.stage, t) !== 'open') throw new HttpError(409, 'This lead is not open at the current stage.');
      if (db.prepare('SELECT 1 FROM unlocks WHERE user_id = ? AND site_id = ? AND trade_id = ?').get(req.user.id, s.id, t.id)) {
        throw new HttpError(409, 'You already unlocked this lead.');
      }
      const taken = db.prepare('SELECT COUNT(*) AS n FROM unlocks WHERE site_id = ? AND trade_id = ?').get(s.id, t.id).n;
      if (taken >= getSettings(db).maxBuyers) throw new HttpError(409, 'All slots for this lead are taken.');
      const price = leadPrice(s, t);
      if (balanceOf(db, req.user.id) < price) {
        throw new HttpError(402, 'Not enough credit. Add credit in Wallet.', { short: true, price });
      }
      db.prepare('INSERT INTO unlocks (user_id, site_id, trade_id, price, ts) VALUES (?,?,?,?,?)').run(req.user.id, s.id, t.id, price, Date.now());
      addLedger(db, req.user.id, 'unlock', -price, `${t.name} lead, ${s.code}`, s.id);
      return { price, site: s };
    });
    res.json({ ok: true, price: out.price, balance: balanceOf(db, req.user.id) });
  });

  r.get('/unlocked', suppliers, (req, res) => {
    const rows = db
      .prepare(
        `SELECT u.trade_id, u.price, u.ts AS bought_at, s.* FROM unlocks u JOIN sites s ON s.id = u.site_id
         WHERE u.user_id = ? ORDER BY u.ts DESC`,
      )
      .all(req.user.id);
    res.json({
      unlocked: rows.map((x) => ({
        tradeId: x.trade_id,
        tradeName: tradeById(x.trade_id)?.name || x.trade_id,
        price: x.price,
        boughtAt: x.bought_at,
        site: fullSite(x),
      })),
    });
  });

  return r;
}
