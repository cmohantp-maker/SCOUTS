// Business constants shared by the server and (through /api/config) the app.

export const STAGES = [
  { n: 1, name: 'Site & excavation' },
  { n: 2, name: 'Foundation' },
  { n: 3, name: 'Structure & slabs' },
  { n: 4, name: 'Brickwork & plastering' },
  { n: 5, name: 'Finishing' },
  { n: 6, name: 'Interiors & handover' },
];

// A trade's lead is open while the site stage is between from..to (inclusive).
// price is the base price in rupees before the commercial multiplier.
export const TRADES = [
  { id: 'material', name: 'Building material', price: 150, from: 1, to: 4 },
  { id: 'cement', name: 'Cement', price: 200, from: 2, to: 4 },
  { id: 'steel', name: 'Steel', price: 300, from: 2, to: 3 },
  { id: 'plumbing', name: 'Plumbing work', price: 150, from: 3, to: 5 },
  { id: 'lift', name: 'Lift', price: 500, from: 3, to: 5 },
  { id: 'electrical', name: 'Electrical items', price: 150, from: 4, to: 5 },
  { id: 'elevation', name: 'Elevation work', price: 300, from: 4, to: 5 },
  { id: 'doors', name: 'Doors & frames', price: 250, from: 4, to: 5 },
  { id: 'tiles', name: 'Tiles', price: 200, from: 4, to: 6 },
  { id: 'plywood', name: 'Plywood', price: 250, from: 5, to: 6 },
  { id: 'interior', name: 'Interior work', price: 400, from: 5, to: 6 },
  { id: 'epoxy', name: 'Epoxy', price: 200, from: 5, to: 6 },
];

export const TYPES = {
  Residential: ['Independent house', 'Villa', 'Apartment block', 'Layout / plots'],
  Commercial: ['Shop / showroom', 'Office building', 'Hotel / restaurant', 'Hospital / school'],
  Others: ['Industrial / warehouse', 'Temple / institutional', 'Renovation'],
};

export const TYPE_MULT = { Residential: 1, Commercial: 1.5, Others: 1 };

export const BUDGETS = ['Under ₹25L', '₹25L–50L', '₹50L–1Cr', '₹1Cr–5Cr', 'Above ₹5Cr'];

export const SCOUT_KINDS = ['Marketing executive', 'Public member'];

// Rules the admin can change in the app. Values are whole numbers.
export const DEFAULT_SETTINGS = {
  radius: 30, // metres: another live site this close blocks a new report
  reward: 150, // rupees paid to a scout once for a verified site
  maxBuyers: 3, // suppliers who can buy the same lead
  minWithdraw: 100, // smallest payout request in rupees
  maxGpsAccuracy: 100, // metres: worse GPS accuracy is rejected outright
};

export const SETTING_LIMITS = {
  radius: [5, 500],
  reward: [0, 5000],
  maxBuyers: [1, 20],
  minWithdraw: [1, 10000],
  maxGpsAccuracy: [10, 1000],
};

export const REJECT_REASONS = [
  'Duplicate site',
  'Photo is unclear',
  'Location does not match photo',
  'Not a construction site',
  'Other',
];

const env = process.env;
export const ENV = {
  port: Number(env.PORT || 3000),
  dataDir: env.DATA_DIR || new URL('../data', import.meta.url).pathname,
  production: env.NODE_ENV === 'production',
  // demo: the login code is returned on screen. Any other value needs an SMS provider (not built yet).
  otpMode: env.OTP_MODE || 'demo',
  // demo: suppliers can add credit without paying. Real payments are not built yet.
  paymentsMode: env.PAYMENTS_MODE || 'demo',
  // Allow typed coordinates. Turn off for the real launch.
  allowManualGps: env.ALLOW_MANUAL_GPS === 'true',
  // Extra secret for admin sign-in. Required in production while OTP_MODE is demo.
  adminPasscode: env.ADMIN_PASSCODE || '',
  adminPhones: (env.ADMIN_PHONES || '')
    .split(',')
    .map((s) => s.replace(/\D/g, '').slice(-10))
    .filter((s) => s.length === 10),
};
