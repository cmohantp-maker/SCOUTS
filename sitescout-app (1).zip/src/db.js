import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { DEFAULT_SETTINGS } from './config.js';

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  phone TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('scout','supplier','admin')),
  kind TEXT NOT NULL,
  trades TEXT NOT NULL DEFAULT '[]',
  upi TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS otps (
  phone TEXT PRIMARY KEY,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  sent_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sites (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  locality TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  acc REAL NOT NULL DEFAULT 0,
  gps_src TEXT NOT NULL DEFAULT 'gps',
  type TEXT NOT NULL,
  sub TEXT NOT NULL,
  stage INTEGER NOT NULL,
  area INTEGER NOT NULL DEFAULT 0,
  budget TEXT NOT NULL DEFAULT '',
  owner_name TEXT NOT NULL,
  owner_phone TEXT NOT NULL DEFAULT '',
  owner_notified INTEGER NOT NULL DEFAULT 0,
  arch_name TEXT NOT NULL DEFAULT '',
  arch_phone TEXT NOT NULL DEFAULT '',
  eng_name TEXT NOT NULL DEFAULT '',
  eng_phone TEXT NOT NULL DEFAULT '',
  builder_name TEXT NOT NULL DEFAULT '',
  builder_phone TEXT NOT NULL DEFAULT '',
  photo TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected')),
  reject_reason TEXT NOT NULL DEFAULT '',
  flags TEXT NOT NULL DEFAULT '[]',
  reporter_id INTEGER NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL,
  verified_at INTEGER
);
CREATE INDEX IF NOT EXISTS sites_geo ON sites (lat, lng);
CREATE INDEX IF NOT EXISTS sites_status ON sites (status);
CREATE INDEX IF NOT EXISTS sites_reporter ON sites (reporter_id);

CREATE TABLE IF NOT EXISTS stage_log (
  id INTEGER PRIMARY KEY,
  site_id INTEGER NOT NULL REFERENCES sites(id),
  stage INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  ts INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS unlocks (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  site_id INTEGER NOT NULL REFERENCES sites(id),
  trade_id TEXT NOT NULL,
  price INTEGER NOT NULL,
  ts INTEGER NOT NULL,
  UNIQUE (user_id, site_id, trade_id)
);

-- Money is never stored as a balance. A balance is the sum of a user's ledger rows.
CREATE TABLE IF NOT EXISTS ledger (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL CHECK (type IN ('reward','topup','unlock','payout','refund')),
  amount INTEGER NOT NULL,
  note TEXT NOT NULL,
  site_id INTEGER,
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_user ON ledger (user_id);

CREATE TABLE IF NOT EXISTS payouts (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  upi TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','paid','rejected')),
  ts INTEGER NOT NULL,
  done_at INTEGER
);

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  ts INTEGER NOT NULL
);
`;

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);
  const ins = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) ins.run(k, v);
  return db;
}

// Runs fn inside one database transaction. The database is used synchronously,
// so nothing else can interleave between the checks and the writes inside fn.
export function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}

export function getSettings(db) {
  const out = {};
  for (const r of db.prepare('SELECT key, value FROM settings').all()) out[r.key] = r.value;
  return out;
}

export const balanceOf = (db, userId) =>
  db.prepare('SELECT COALESCE(SUM(amount),0) AS b FROM ledger WHERE user_id = ?').get(userId).b;

export function addLedger(db, userId, type, amount, note, siteId = null) {
  db.prepare('INSERT INTO ledger (user_id, type, amount, note, site_id, ts) VALUES (?,?,?,?,?,?)').run(
    userId,
    type,
    amount,
    note,
    siteId,
    Date.now(),
  );
}

export function audit(db, userId, action, detail = '') {
  db.prepare('INSERT INTO audit (user_id, action, detail, ts) VALUES (?,?,?,?)').run(userId, action, String(detail).slice(0, 500), Date.now());
}

export function nextSiteCode(db) {
  const row = db.prepare('SELECT COUNT(*) AS n FROM sites').get();
  return 'SS-' + String(row.n + 1).padStart(4, '0');
}
