/* SiteScout web app. Talks to the server in /api. The server decides everything that matters
   (duplicates, who can see contacts, money). This file only shows screens and collects input. */
'use strict';

const S = {
  cfg: null,
  me: null,
  tab: null,
  balance: null,
  data: {},
  loading: false,
  err: '',
  open: null,
  leadTab: 'open',
  reviewTab: 'pending',
  reject: null,
  busy: false,
  manualOpen: false,
  install: null,
  draft: null,
  auth: { step: 'phone', phone: '', exists: null, demoCode: '', code: '', name: '', role: 'scout', kind: 'Public member', trades: [], pass: '' },
  wd: { upi: '', amt: '' },
};

const TABS = {
  scout: [['report', 'Report'], ['sites', 'My sites'], ['wallet', 'Wallet']],
  supplier: [['leads', 'Leads'], ['unlocked', 'Unlocked'], ['wallet', 'Wallet']],
  admin: [['review', 'Review'], ['payouts', 'Payouts'], ['insights', 'Insights']],
};
const ICONS = {
  report: '<path d="M4 8h3l2-2.5h6L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  sites: '<path d="M12 21s-6-5.6-6-10.5a6 6 0 1 1 12 0C18 15.4 12 21 12 21z"/><circle cx="12" cy="10.5" r="2.2"/>',
  wallet: '<rect x="3.5" y="6.5" width="17" height="12" rx="2"/><path d="M16 12.5h2.5M3.5 9.5h17"/>',
  leads: '<path d="M4 19V9l8-5 8 5v10z"/><path d="M9 19v-6h6v6z"/>',
  unlocked: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8.5 11V8a3.5 3.5 0 0 1 6.8-1.2"/>',
  review: '<circle cx="12" cy="12" r="8.5"/><path d="M8 12.3l2.8 2.8 5.4-5.6"/>',
  payouts: '<path d="M7 6h10M7 10h10M9 6c4 0 5.5 2 5.5 4s-1.5 4-5.5 4l6 5"/>',
  insights: '<path d="M5 19v-8M12 19V5M19 19v-6"/>',
};
const LOGO =
  '<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="16" cy="16" r="8"/><path d="M16 3v6M16 23v6M3 16h6M23 16h6"/><circle cx="16" cy="16" r="1.6" fill="currentColor"/></svg>';
const TEST_SPOTS = [['Vadavalli, Coimbatore', 11.0237, 76.9061], ['Ganapathy, Coimbatore', 11.0328, 76.9894], ['Peelamedu, Coimbatore', 11.0265, 77.005]];

/* ---------- helpers ---------- */
const $app = document.getElementById('app');
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = (n) => (n < 0 ? '-' : '') + '₹' + Math.abs(n).toLocaleString('en-IN');
const fmtDT = (ts) => new Date(ts).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const fmtD = (ts) => new Date(ts).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
const mapUrl = (p) => 'https://www.google.com/maps?q=' + p.lat + ',' + p.lng;
const stageName = (n) => (S.cfg.stages.find((s) => s.n === n) || {}).name || '';
const tradeName = (id) => (S.cfg.trades.find((t) => t.id === id) || {}).name || id;

let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3600);
}

async function api(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: { 'content-type': 'application/json' },
      body: method === 'GET' ? undefined : JSON.stringify(body || {}),
    });
  } catch (e) {
    throw Object.assign(new Error('No internet connection. Check your network and try again.'), { offline: true });
  }
  let json = {};
  try {
    json = await res.json();
  } catch (e) {
    /* empty body */
  }
  if (!res.ok) {
    if (res.status === 401 && S.me && !url.includes('/auth/')) {
      S.me = null;
      S.data = {};
      render();
    }
    throw Object.assign(new Error(json.error || 'Something went wrong. Try again.'), { status: res.status, data: json });
  }
  return json;
}

function newDraft() {
  return {
    photo: null,
    gps: null,
    gpsStatus: 'idle',
    gpsMsg: '',
    liveAcc: null,
    dup: null,
    manual: { lat: '', lng: '' },
    name: '',
    locality: '',
    type: 'Residential',
    sub: S.cfg.types.Residential[0],
    stage: '1',
    owner: '',
    ownerPhone: '',
    arch: '',
    archPhone: '',
    eng: '',
    engPhone: '',
    builder: '',
    builderPhone: '',
    area: '',
    budget: '',
    notified: false,
  };
}

/* ---------- small view pieces ---------- */
function badge(status) {
  if (status === 'verified') return '<span class="badge ok">Verified</span>';
  if (status === 'pending') return '<span class="badge warn">Awaiting review</span>';
  return '<span class="badge bad">Rejected</span>';
}
function inp(label, path, val, o) {
  o = o || {};
  const id = 'f_' + path.replace(/\./g, '_');
  return (
    '<div class="field"><label for="' + id + '">' + label + (o.req ? '<span class="req">required</span>' : '') + '</label><input id="' + id + '" data-bind="' + path + '" type="' + (o.type || 'text') + '" value="' + esc(val) + '"' +
    (o.mode ? ' inputmode="' + o.mode + '"' : '') + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.max ? ' maxlength="' + o.max + '"' : '') + (o.auto ? ' autocomplete="' + o.auto + '"' : ' autocomplete="off"') + '></div>'
  );
}
function sel(label, path, val, opts) {
  const id = 'f_' + path.replace(/\./g, '_');
  return (
    '<div class="field"><label for="' + id + '">' + label + '</label><select id="' + id + '" data-bind="' + path + '">' +
    opts.map((x) => { const v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : x; return '<option value="' + esc(v) + '"' + (String(v) === String(val) ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('') + '</select></div>'
  );
}
function phoneLine(p) {
  if (!p || (!p.name && !p.phone)) return '<span class="muted">Not known</span>';
  let h = esc(p.name || '');
  if (p.phone) {
    h += (p.name ? '<br>' : '') + '<span class="mono">' + esc(p.phone) + '</span> <button class="btn sm ghost" data-act="copy" data-v="' + esc(p.phone) + '">Copy</button> <a class="small" href="tel:' + esc(p.phone.replace(/\s/g, '')) + '">Call</a>';
  }
  return h;
}
function photoBlock(p) {
  return p.photo ? '<img class="photo" src="' + esc(p.photo) + '" alt="Photo of site ' + esc(p.code) + '" loading="lazy">' : '<div class="photo noimg">No photo</div>';
}
function qualityBar(q) {
  return '<div class="row small muted" style="gap:8px;flex-wrap:nowrap"><span style="white-space:nowrap">Lead quality ' + q + '/100</span><div class="meter" style="flex:1"><i style="width:' + q + '%"></i></div></div>';
}
function barRow(label, val, max) {
  return '<div class="bar"><span>' + esc(label) + '</span><div class="track"><i style="width:' + (max ? Math.round((val / max) * 100) : 0) + '%"></i></div><span>' + val + '</span></div>';
}
const empty = (title, text) => '<div class="empty"><b>' + title + '</b><span>' + text + '</span></div>';
const loadingBox = () => '<div class="panel"><p class="loading">Loading…</p></div>';
function errBox() {
  return S.err ? '<div class="banner bad"><b>Could not load</b><span>' + esc(S.err) + '</span><div class="row"><button class="btn sm ghost" data-act="retry">Try again</button></div></div>' : '';
}
function ledgerList(rows) {
  if (!rows.length) return '<div class="panel">' + empty('No transactions yet', 'Money in and out will show here.') + '</div>';
  return '<div class="panel flat">' + rows.map((l) => '<div class="item"><div class="item-h"><div class="t"><strong>' + esc(l.note) + '</strong><span class="small muted">' + fmtDT(l.ts) + '</span></div><strong class="tabular" style="color:var(--' + (l.amount >= 0 ? 'ok' : 'ink') + ')">' + (l.amount >= 0 ? '+' : '') + inr(l.amount) + '</strong></div></div>').join('') + '</div>';
}

/* ---------- sign in ---------- */
function viewAuth() {
  const a = S.auth;
  let body = '';
  if (a.step === 'phone') {
    body =
      '<div class="panel"><h2>Sign in or join</h2><p class="muted small">Use your mobile number. We send a 6-digit code.</p>' +
      inp('Mobile number', 'auth.phone', a.phone, { type: 'tel', mode: 'numeric', ph: '98765 43210', max: 16, auto: 'tel' }) +
      '<button class="btn mark block" data-act="auth-request"' + (S.busy ? ' disabled' : '') + '>Get code</button></div>';
  } else {
    const sup = a.role === 'supplier';
    body =
      '<div class="panel"><h2>Enter the code</h2><p class="muted small">Sent to <span class="mono">' + esc(a.phone) + '</span>. <button class="linkbtn" style="display:inline;width:auto;color:var(--steel)" data-act="auth-back">Change number</button></p>' +
      (a.demoCode ? '<div class="banner warn"><b>Test version</b><span>SMS is not connected yet, so your code is shown here:</span></div><div class="codebox" aria-label="Your code">' + esc(a.demoCode) + '</div>' : '') +
      inp('6-digit code', 'auth.code', a.code, { type: 'text', mode: 'numeric', ph: '000000', max: 6, auto: 'one-time-code' });
    if (a.exists === false) {
      body +=
        inp('Your name', 'auth.name', a.name, { req: 1, max: 60, auto: 'name' }) +
        '<div class="field"><label>I am a</label><div class="seg" role="group" aria-label="Member type">' +
        [['Marketing executive', 'scout'], ['Public member', 'scout'], ['Material supplier', 'supplier']].map(([k, role]) => '<button type="button" data-act="auth-kind" data-v="' + k + '" data-role="' + role + '" aria-pressed="' + (a.kind === k) + '">' + k + '</button>').join('') + '</div></div>' +
        (sup ? '<div class="field"><label>Trades you sell</label><div class="chips">' + S.cfg.trades.map((t) => '<button type="button" class="chip" data-act="auth-trade" data-v="' + t.id + '" aria-pressed="' + a.trades.includes(t.id) + '">' + esc(t.name) + '</button>').join('') + '</div></div>' : '<p class="small muted">Scouts find construction sites, report them and are paid ₹' + S.cfg.settings.reward + ' for each verified site.</p>');
    }
    body += '<details><summary class="small muted">Admin sign-in</summary>' + inp('Admin passcode', 'auth.pass', a.pass, { type: 'password', max: 100, auto: 'current-password' }) + '</details>';
    body += '<button class="btn mark block" data-act="auth-verify"' + (S.busy ? ' disabled' : '') + '>' + (a.exists === false ? 'Create account' : 'Sign in') + '</button><button class="btn ghost block" data-act="auth-request">Send code again</button></div>';
  }
  return '<div class="wrap auth"><div class="brand logo-lg">' + LOGO + '<span>SiteScout</span></div><p class="muted">Report construction sites with photo and exact location. Suppliers buy leads at the right building stage.</p>' + body + '</div>';
}

/* ---------- scout: report ---------- */
function missing(d) {
  const m = [];
  if (!d.photo) m.push('site photo');
  if (!d.gps) m.push('location');
  else if (d.dup && d.dup.duplicate) m.push('a site that is not already reported');
  if (d.locality.trim().length < 2) m.push('area name');
  if (d.owner.trim().length < 2) m.push('owner name');
  if (!d.notified) m.push('owner notice');
  return m;
}
function viewReport() {
  const d = S.draft;
  const miss = missing(d);
  const stamp = d.gps ? d.gps.lat + ', ' + d.gps.lng + (d.gps.src === 'gps' ? ' · ±' + d.gps.acc + ' m' : ' · typed') + ' · ' + fmtDT(Date.now()) : '';
  const step1 =
    '<section class="panel step"><div class="step-h"><span class="stepno">1</span><h2>Site photo</h2></div>' +
    (d.photo ? '<div class="shot"><img src="' + d.photo + '" alt="Photo you took of the site"><div class="stampov mono">' + esc(stamp || 'Location not captured yet') + '</div></div>' : '<div class="shot empty">Photograph the board, gate or structure so the site can be recognised later.</div>') +
    '<input type="file" id="photoIn" accept="image/*" capture="environment" hidden>' +
    '<button class="btn steel block" data-act="photo">' + (d.photo ? 'Retake photo' : 'Take site photo') + '</button></section>';

  let loc = '';
  if (d.gps) {
    const g = d.gps;
    loc += '<div class="coords"><span class="small muted">' + (g.src === 'gps' ? 'Captured from GPS' : 'Typed by hand (test only)') + '</span><span class="big">' + g.lat + ', ' + g.lng + '</span><div class="row small"><span>' + (g.src === 'gps' ? 'Accuracy ±' + g.acc + ' m' : 'Accuracy unknown') + '</span><a href="' + mapUrl(g) + '" target="_blank" rel="noopener">View on map</a></div></div>';
    if (g.src === 'gps' && g.acc > 50) loc += '<div class="banner warn"><b>Weak GPS signal</b><span>Move to open sky and capture again for a tighter fix.</span></div>';
    if (d.dup && d.dup.duplicate) {
      loc += '<div class="banner bad"><b>This site is already reported</b><span>A site ' + d.dup.distance + ' m from this spot is already listed' + (d.dup.own ? ' (you reported it as ' + esc(d.dup.code) + ')' : ' by another member') + '. Each site can be reported once, so this one cannot be submitted.</span></div>';
    } else if (d.dup) {
      loc += '<div class="banner ok"><b>New site</b><span>Nothing reported within ' + S.cfg.settings.radius + ' m of this spot.</span></div>';
    }
  } else if (d.gpsStatus === 'locating') {
    loc += '<div class="banner warn"><b>Reading GPS…</b><span>Stay outdoors and keep still for about 10 seconds.' + (d.liveAcc ? ' Accuracy so far ±' + d.liveAcc + ' m.' : '') + '</span></div>';
  }
  if (d.gpsStatus === 'error') loc += '<div class="banner warn"><b>Location not available</b><span>' + esc(d.gpsMsg) + '</span></div>';

  let manual = '';
  if (S.cfg.allowManualGps && (S.manualOpen || d.gpsStatus === 'error')) {
    manual =
      '<div class="panel" style="background:transparent"><b class="small">Test mode: type coordinates</b><p class="small muted">Only on this test server. The live app will not allow typing a location.</p><div class="fields">' +
      inp('Latitude', 'draft.manual.lat', d.manual.lat, { mode: 'decimal', ph: '11.0168' }) + inp('Longitude', 'draft.manual.lng', d.manual.lng, { mode: 'decimal', ph: '76.9558' }) + '</div>' +
      '<div class="field"><label for="spot">Or pick a test spot</label><select id="spot"><option value="">Choose…</option>' + TEST_SPOTS.map((t, i) => '<option value="' + i + '">' + esc(t[0]) + '</option>').join('') + '</select></div>' +
      '<button class="btn ghost block" data-act="manual-use">Use these coordinates</button></div>';
  }
  const step2 =
    '<section class="panel step"><div class="step-h"><span class="stepno">2</span><h2>Exact location</h2></div>' + loc +
    '<button class="btn steel block" data-act="locate"' + (d.gpsStatus === 'locating' ? ' disabled' : '') + '>' + (d.gps ? 'Capture again' : 'Capture exact location') + '</button>' +
    (S.cfg.allowManualGps && !(S.manualOpen || d.gpsStatus === 'error') ? '<button class="btn sm ghost" data-act="manual-open" style="align-self:flex-start">GPS blocked? Type coordinates</button>' : '') + manual + '</section>';

  const types = Object.keys(S.cfg.types);
  const step3 =
    '<section class="panel step"><div class="step-h"><span class="stepno">3</span><h2>Project</h2></div><div class="fields">' +
    inp('Area or locality', 'draft.locality', d.locality, { req: 1, ph: 'e.g. Singanallur', max: 60 }) + inp('Site name or landmark', 'draft.name', d.name, { ph: 'e.g. Plot 14, Gandhi Nagar', max: 80 }) + '</div>' +
    '<div class="field"><label>Type of project</label><div class="seg" role="group" aria-label="Type of project">' + types.map((t) => '<button type="button" data-act="type" data-v="' + t + '" aria-pressed="' + (d.type === t) + '">' + t + '</button>').join('') + '</div></div>' +
    '<div class="fields">' + sel('Kind', 'draft.sub', d.sub, S.cfg.types[d.type]) + sel('Current stage', 'draft.stage', d.stage, S.cfg.stages.map((s) => [s.n, s.n + '. ' + s.name])) + '</div>' +
    '<div class="fields">' + inp('Built-up area (sq ft)', 'draft.area', d.area, { type: 'number', mode: 'numeric' }) + sel('Estimated budget', 'draft.budget', d.budget, [['', 'Not known']].concat(S.cfg.budgets.map((b) => [b, b]))) + '</div></section>';

  const person = (lab, nk, pk, req) => '<div class="fields">' + inp(lab, 'draft.' + nk, d[nk], { req, max: 80 }) + inp(lab + ' phone', 'draft.' + pk, d[pk], { type: 'tel', mode: 'tel', max: 20 }) + '</div>';
  const step4 =
    '<section class="panel step"><div class="step-h"><span class="stepno">4</span><h2>People on the project</h2></div><p class="small muted">Fill what you can. Complete contacts make the lead worth more.</p>' +
    person('Owner', 'owner', 'ownerPhone', 1) + person('Architect', 'arch', 'archPhone') + person('Engineer', 'eng', 'engPhone') + person('Builder', 'builder', 'builderPhone') +
    '<label class="row" style="gap:10px;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" id="notified" data-bind="draft.notified" data-check="1"' + (d.notified ? ' checked' : '') + ' style="width:22px;height:22px;margin-top:2px;flex:none"><span class="small">I told the owner that this site is listed on SiteScout and its contact details are shared with suppliers.</span></label></section>';

  const step5 =
    '<section class="panel step"><div class="step-h"><span class="stepno">5</span><h2>Submit</h2></div>' +
    (miss.length ? '<p class="small muted">Still needed: ' + miss.join(', ') + '.</p>' : '<p class="small muted">Everything is ready. You are paid ' + inr(S.cfg.settings.reward) + ' once, when the site is verified.</p>') +
    '<button class="btn mark block" data-act="submit"' + (miss.length || S.busy ? ' aria-disabled="true"' : '') + '>' + (S.busy ? 'Submitting…' : 'Submit site') + '</button></section>';

  return '<div class="pagehead"><h1>Report a site</h1><p class="muted">Photo, exact location and the people behind the project.</p></div>' + step1 + step2 + step3 + step4 + step5;
}

/* ---------- scout: my sites ---------- */
function tradeTable(p) {
  return '<div class="scroll-x"><table class="tbl"><thead><tr><th>Trade</th><th>Stages</th><th>Now</th><th>Price</th><th>Sold</th></tr></thead><tbody>' +
    p.trades.map((t) => {
      const b = t.state === 'open' ? '<span class="badge ok">Open</span>' : t.state === 'upcoming' ? '<span class="badge plain">Soon</span>' : '<span class="badge plain">Closed</span>';
      return '<tr><td>' + esc(t.name) + '</td><td class="tabular">' + t.from + '–' + t.to + '</td><td>' + b + '</td><td class="tabular">' + inr(t.price) + '</td><td class="tabular">' + t.sold + '/' + t.maxBuyers + '</td></tr>';
    }).join('') + '</tbody></table></div>';
}
function siteFacts(p, admin) {
  let h = '<dl class="kv"><dt>Type</dt><dd>' + esc(p.type) + ' · ' + esc(p.sub) + '</dd><dt>Stage</dt><dd>' + p.stage + '. ' + esc(stageName(p.stage)) + '</dd>' +
    (p.area ? '<dt>Built-up area</dt><dd class="tabular">' + p.area.toLocaleString('en-IN') + ' sq ft</dd>' : '') + (p.budget ? '<dt>Budget</dt><dd>' + esc(p.budget) + '</dd>' : '') +
    '<dt>Location</dt><dd><span class="mono">' + p.lat + ', ' + p.lng + '</span><br><span class="small muted">' + (p.gpsSrc === 'gps' ? 'GPS ±' + p.acc + ' m' : 'Typed by hand') + '</span> · <a class="small" href="' + mapUrl(p) + '" target="_blank" rel="noopener">Map</a></dd>' +
    '<dt>Owner</dt><dd>' + phoneLine(p.owner) + '</dd><dt>Architect</dt><dd>' + phoneLine(p.architect) + '</dd><dt>Engineer</dt><dd>' + phoneLine(p.engineer) + '</dd><dt>Builder</dt><dd>' + phoneLine(p.builder) + '</dd>' +
    (admin && p.reporter ? '<dt>Reported by</dt><dd>' + esc(p.reporter.name) + ' <span class="small muted">(' + esc(p.reporter.kind) + ')</span><br><span class="mono">' + esc(p.reporter.phone) + '</span><br><span class="small muted">' + fmtDT(p.createdAt) + '</span></dd>' : '') + '</dl>';
  if (admin && p.flags && p.flags.length) h += '<div class="banner warn"><b>Check before approving</b>' + p.flags.map((f) => '<span>' + esc(f) + '</span>').join('') + '</div>';
  return h;
}
function viewSites() {
  const sites = S.data.sites;
  if (!sites) return errBox() || loadingBox();
  const earned = sites.filter((p) => p.status === 'verified').length * S.cfg.settings.reward;
  let h = '<div class="pagehead"><h1>My sites</h1><p class="muted">' + sites.length + ' reported · ' + inr(earned) + ' earned from them</p></div>';
  if (!sites.length) return h + '<div class="panel">' + empty('No sites yet', 'Report your first site from the Report tab.') + '</div>';
  h += '<div class="panel flat">' + sites.map((p) => {
    const open = S.open === p.code;
    let body = '';
    if (open) {
      body = '<div style="display:flex;flex-direction:column;gap:12px;margin-top:4px">' + photoBlock(p) + siteFacts(p, false);
      if (p.status === 'rejected') body += '<div class="banner bad"><b>Rejected</b><span>' + esc(p.rejectReason || 'No reason given') + '</span></div>';
      if (p.status === 'verified') {
        body += '<h3>Trade leads from this site</h3><p class="small muted">You were paid ' + inr(S.cfg.settings.reward) + ' when this site was verified. Leads open and close as the site moves through stages. Keep the stage up to date so suppliers see fresh leads.</p>' + tradeTable(p);
        const later = S.cfg.stages.filter((s) => s.n > p.stage);
        body += later.length ? '<div class="fields" style="align-items:flex-end"><div class="field"><label for="ns_' + p.code + '">Update stage</label><select id="ns_' + p.code + '">' + later.map((s) => '<option value="' + s.n + '">' + s.n + '. ' + esc(s.name) + '</option>').join('') + '</select></div><button class="btn steel" data-act="stage" data-id="' + p.code + '">Update</button></div>' : '<p class="small muted">This site is at the last stage.</p>';
      }
      if (p.status === 'pending') body += '<p class="small muted">The admin will check the photo and location. You are paid ' + inr(S.cfg.settings.reward) + ' once it is verified.</p>';
      body += '</div>';
    }
    return '<div class="item"><button class="linkbtn" data-act="open-site" data-id="' + p.code + '" aria-expanded="' + open + '"><div class="item-h"><div class="t"><strong>' + esc(p.name) + '</strong><span class="small muted"><span class="mono">' + p.code + '</span> · ' + esc(p.locality) + ' · ' + esc(p.sub) + '</span></div>' + badge(p.status) + '</div></button>' + body + '</div>';
  }).join('') + '</div>';
  return h;
}

/* ---------- wallet ---------- */
function viewWallet() {
  const w = S.data.wallet;
  if (!w) return errBox() || loadingBox();
  const sup = S.me.role === 'supplier';
  let h = '<div class="pagehead"><h1>Wallet</h1></div><div class="panel"><span class="small muted">' + (sup ? 'Lead credit' : 'Available to withdraw') + '</span><div class="bal">' + inr(w.balance) + '</div>';
  if (sup) {
    h += w.topupEnabled
      ? '<div class="row">' + [500, 1000, 2000].map((a) => '<button class="btn sm steel" data-act="topup" data-v="' + a + '">Add ' + inr(a) + '</button>').join('') + '</div><p class="small muted">Test version: credit is added without payment. Online payment is added before launch.</p></div>'
      : '<p class="small muted">Ask the admin to add credit to your account.</p></div>';
  } else {
    const upi = S.wd.upi || S.me.upi || '';
    h += '<div class="small muted tabular">Earned in total ' + inr(w.earned) + '</div></div><div class="panel"><h3>Withdraw to UPI</h3><div class="fields">' +
      inp('UPI ID', 'wd.upi', upi, { ph: 'name@bank', max: 64 }) + inp('Amount (₹)', 'wd.amt', S.wd.amt !== '' ? S.wd.amt : w.balance > 0 ? w.balance : '', { type: 'number', mode: 'numeric' }) +
      '</div><button class="btn mark block" data-act="payout">Request payout</button><p class="small muted">Smallest payout ' + inr(w.minWithdraw) + '. The admin pays it to your UPI ID and marks it paid.</p>' +
      (w.payouts.length ? '<div class="small">' + w.payouts.map((x) => '<div class="row split" style="padding:4px 0"><span>' + inr(x.amount) + ' to <span class="mono">' + esc(x.upi) + '</span></span><span class="badge ' + (x.status === 'paid' ? 'ok' : x.status === 'rejected' ? 'bad' : 'warn') + '">' + (x.status === 'paid' ? 'Paid' : x.status === 'rejected' ? 'Returned' : 'Requested') + '</span></div>').join('') + '</div>' : '') + '</div>';
  }
  return h + '<h3 style="padding-top:4px">History</h3>' + ledgerList(w.ledger);
}

/* ---------- supplier ---------- */
function viewLeads() {
  const leads = S.data.leads;
  let h = '<div class="pagehead"><h1>Leads</h1><p class="muted">Verified sites that need what you sell, by building stage.</p></div>' +
    '<div class="panel"><b class="small">Trades you sell</b><div class="chips">' + S.cfg.trades.map((t) => '<button class="chip" data-act="mytrade" data-v="' + t.id + '" aria-pressed="' + S.me.trades.includes(t.id) + '">' + esc(t.name) + '</button>').join('') + '</div></div>' +
    '<div class="seg" role="group" aria-label="Lead timing"><button data-act="leadtab" data-v="open" aria-pressed="' + (S.leadTab === 'open') + '">Open now</button><button data-act="leadtab" data-v="soon" aria-pressed="' + (S.leadTab === 'soon') + '">Coming up</button></div>';
  if (!leads) return h + (errBox() || loadingBox());
  if (!leads.length) return h + '<div class="panel">' + empty('No leads here right now', 'Open leads appear as verified sites reach the right stage.') + '</div>';
  const soon = S.leadTab === 'soon';
  return h + '<div class="panel flat">' + leads.map((l) => {
    return '<div class="item"><div class="item-h"><div class="t"><strong>' + esc(l.tradeName) + '</strong><span class="small muted">' + esc(l.type) + ' · ' + esc(l.sub) + ' · ' + esc(l.locality) + '</span></div><strong class="tabular">' + inr(l.price) + '</strong></div>' +
      '<div class="row small muted"><span class="mono">' + esc(l.siteCode) + '</span><span>Stage ' + l.stage + ', ' + esc(l.stageName) + '</span>' + (l.area ? '<span class="tabular">' + l.area.toLocaleString('en-IN') + ' sq ft</span>' : '') + (l.budget ? '<span>' + esc(l.budget) + '</span>' : '') + '</div>' +
      qualityBar(l.quality) +
      (soon ? '<span class="small muted">Opens at stage ' + l.opensAtStage + ', ' + esc(l.opensAtName) + '.</span>' : '<div class="row split"><span class="small ' + (l.slotsLeft ? 'muted' : '') + '">' + (l.slotsLeft ? l.slotsLeft + ' of ' + l.maxBuyers + ' slots left' : 'All slots taken') + '</span><button class="btn mark sm" data-act="unlock" data-p="' + esc(l.siteCode) + '" data-t="' + esc(l.tradeId) + '"' + (l.slotsLeft ? '' : ' disabled') + '>Unlock for ' + inr(l.price) + '</button></div>') + '</div>';
  }).join('') + '</div>';
}
function viewUnlocked() {
  const list = S.data.unlocked;
  if (!list) return errBox() || loadingBox();
  const h = '<div class="pagehead"><h1>Unlocked</h1><p class="muted">Full details of the leads you bought.</p></div>';
  if (!list.length) return h + '<div class="panel">' + empty('Nothing unlocked yet', 'Unlock a lead and the owner, architect, engineer and builder details show here.') + '</div>';
  return h + list.map((u) => '<div class="panel"><div class="item-h"><div class="t"><strong>' + esc(u.tradeName) + ' · ' + esc(u.site.name) + '</strong><span class="small muted"><span class="mono">' + esc(u.site.code) + '</span> · ' + esc(u.site.locality) + ' · bought ' + fmtD(u.boughtAt) + ' for ' + inr(u.price) + '</span></div></div>' + photoBlock(u.site) + siteFacts(u.site, false) + '<p class="small muted">Now at stage ' + u.site.stage + ', ' + esc(stageName(u.site.stage)) + '.</p></div>').join('');
}

/* ---------- admin ---------- */
function reviewCard(p) {
  const rj = S.reject && S.reject.code === p.code;
  let acts = '';
  if (p.status === 'pending') {
    acts = rj
      ? '<div class="fields" style="align-items:flex-end">' + sel('Reason', 'reject.reason', S.reject.reason, S.cfg.rejectReasons) + '<button class="btn danger" data-act="reject-do" data-id="' + p.code + '">Confirm reject</button><button class="btn ghost" data-act="reject-cancel">Cancel</button></div>'
      : '<div class="row"><button class="btn mark" data-act="approve" data-id="' + p.code + '" style="flex:1">Approve</button><button class="btn ghost" data-act="reject-ask" data-id="' + p.code + '">Reject</button></div>';
  }
  return '<div class="panel"><div class="item-h"><div class="t"><strong>' + esc(p.name) + '</strong><span class="small muted"><span class="mono">' + p.code + '</span> · ' + esc(p.locality) + '</span></div>' + badge(p.status) + '</div>' + photoBlock(p) + siteFacts(p, true) + (p.status === 'rejected' ? '<div class="banner bad"><span>' + esc(p.rejectReason) + '</span></div>' : '') + acts + '</div>';
}
function viewReview() {
  const list = S.data.adminSites;
  const h = '<div class="pagehead"><h1>Review</h1><p class="muted">Check photo, location and details before a site goes live to suppliers.</p></div>' +
    '<div class="seg" role="group" aria-label="Filter"><button data-act="reviewtab" data-v="pending" aria-pressed="' + (S.reviewTab === 'pending') + '">Waiting</button><button data-act="reviewtab" data-v="all" aria-pressed="' + (S.reviewTab === 'all') + '">All sites</button></div>';
  if (!list) return h + (errBox() || loadingBox());
  return h + (list.length ? list.map(reviewCard).join('') : '<div class="panel">' + empty('Nothing waiting', 'New reports from scouts appear here.') + '</div>');
}
function viewPayouts() {
  const reqs = S.data.payouts;
  const h = '<div class="pagehead"><h1>Payouts</h1><p class="muted">Scout withdrawal requests. Pay the UPI ID, then mark it paid.</p></div>';
  if (!reqs) return h + (errBox() || loadingBox());
  if (!reqs.length) return h + '<div class="panel">' + empty('No requests', 'Scouts request payouts from their wallet.') + '</div>';
  return h + '<div class="panel flat">' + reqs.map((x) =>
    '<div class="item"><div class="item-h"><div class="t"><strong>' + esc(x.user.name || 'Unknown') + '</strong><span class="small muted">' + fmtDT(x.ts) + ' · <span class="mono">' + esc(x.upi) + '</span></span></div><strong class="tabular">' + inr(x.amount) + '</strong></div><div class="row split"><span class="badge ' + (x.status === 'paid' ? 'ok' : x.status === 'rejected' ? 'bad' : 'warn') + '">' + (x.status === 'paid' ? 'Paid' : x.status === 'rejected' ? 'Returned' : 'Requested') + '</span>' +
    (x.status === 'requested' ? '<span class="row"><button class="btn sm ghost" data-act="payout-reject" data-id="' + x.id + '">Return money</button><button class="btn sm steel" data-act="payout-paid" data-id="' + x.id + '">Mark paid</button></span>' : '') + '</div></div>').join('') + '</div>';
}
function viewInsights() {
  const i = S.data.insights, st = S.data.settings, users = S.data.users;
  const h = '<div class="pagehead"><h1>Insights</h1><p class="muted">What is being reported and what is selling.</p></div>';
  if (!i || !st || !users) return h + (errBox() || loadingBox());
  const mx = (a, k) => Math.max(1, ...a.map((r) => r[k]));
  const set = (k, l) => '<div class="field"><label for="s_' + k + '">' + l + '</label><input id="s_' + k + '" type="number" inputmode="numeric" data-set="' + k + '" value="' + st.settings[k] + '" min="' + st.limits[k][0] + '" max="' + st.limits[k][1] + '"></div>';
  return h +
    '<div class="stats"><div class="stat"><b>' + i.reported + '</b><span>Reported</span></div><div class="stat"><b>' + i.verified + '</b><span>Verified</span></div><div class="stat"><b>' + i.pending + '</b><span>Waiting</span></div><div class="stat"><b>' + i.leadsSold + '</b><span>Leads sold</span></div><div class="stat"><b>' + inr(i.revenue) + '</b><span>Lead sales</span></div><div class="stat"><b>' + inr(i.rewardsPaid) + '</b><span>Rewards paid</span></div></div>' +
    '<div class="panel"><h3>Verified sites by stage</h3><div class="bars">' + i.byStage.map((r) => barRow(r.name, r.n, mx(i.byStage, 'n'))).join('') + '</div></div>' +
    '<div class="panel"><h3>Verified sites by type</h3><div class="bars">' + i.byType.map((r) => barRow(r.name, r.n, mx(i.byType, 'n'))).join('') + '</div></div>' +
    '<div class="panel"><h3>Open leads by trade</h3><p class="small muted">Bar = verified sites at the right stage now. Number on the right = leads sold.</p><div class="bars">' + i.byTrade.map((r) => '<div class="bar"><span>' + esc(r.name) + '</span><div class="track"><i style="width:' + Math.round((r.open / mx(i.byTrade, 'open')) * 100) + '%"></i></div><span>' + r.open + '·' + r.sold + '</span></div>').join('') + '</div></div>' +
    '<div class="panel"><h3>Rules</h3><div class="fields">' + set('radius', 'Duplicate radius (m)') + set('reward', 'Reward per verified site (₹)') + set('maxBuyers', 'Buyers per lead') + set('minWithdraw', 'Smallest payout (₹)') + set('maxGpsAccuracy', 'Worst GPS accuracy allowed (m)') + '</div><p class="small muted">Changes apply to new reports and sales straight away.</p></div>' +
    '<div class="panel"><h3>People (' + users.length + ')</h3><div class="panel flat" style="border:0">' + users.map((u) =>
      '<div class="item"><div class="item-h"><div class="t"><strong>' + esc(u.name) + '</strong><span class="small muted">' + esc(u.kind) + ' · <span class="mono">' + esc(u.phone) + '</span>' + (u.role === 'scout' ? ' · ' + u.reports + ' reported, ' + u.verified + ' verified, ' + u.rejected + ' rejected' : '') + '</span></div>' +
      (u.role === 'admin' ? '<span class="badge plain">Admin</span>' : '<button class="btn sm ' + (u.status === 'active' ? 'ghost' : 'danger') + '" data-act="user-toggle" data-id="' + u.id + '" data-v="' + (u.status === 'active' ? 'suspended' : 'active') + '">' + (u.status === 'active' ? 'Pause' : 'Resume') + '</button>') + '</div></div>').join('') + '</div></div>';
}

/* ---------- shell ---------- */
function header() {
  const u = S.me;
  return '<header class="top"><div class="wrap top-in"><div class="brand">' + LOGO + '<span>SiteScout</span></div><div class="who">' +
    (S.install ? '<button class="btn sm ghost" data-act="install">Install</button>' : '') +
    '<button class="btn sm ghost" data-act="logout">Sign out</button></div></div><div class="wrap roleline"><span class="badge plain">' + (u.role === 'admin' ? 'Admin' : u.role === 'supplier' ? 'Supplier' : 'Scout') + '</span><span class="name">' + esc(u.name) + '</span>' +
    (u.role !== 'admin' && S.balance != null ? '<span aria-hidden="true">·</span><span class="tabular">Balance ' + inr(S.balance) + '</span>' : '') + '</div></header>';
}
function nav() {
  return '<nav class="tabs" aria-label="Main"><div class="wrap"><div class="tabs-in">' + TABS[S.me.role].map((t) => '<button class="tab" data-act="tab" data-v="' + t[0] + '"' + (S.tab === t[0] ? ' aria-current="page"' : '') + '><svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[t[0]] + '</svg>' + t[1] + '</button>').join('') + '</div></div></nav>';
}
function render() {
  if (!S.cfg) return;
  const active = document.activeElement;
  const keep = active && active.id && /^f_|^s_|^ns_/.test(active.id) ? active.id : null;
  if (!S.me) {
    $app.innerHTML = viewAuth();
  } else {
    const t = S.tab;
    let v = '';
    if (S.me.role === 'scout') v = t === 'report' ? viewReport() : t === 'sites' ? viewSites() : viewWallet();
    else if (S.me.role === 'supplier') v = t === 'leads' ? viewLeads() : t === 'unlocked' ? viewUnlocked() : viewWallet();
    else v = t === 'review' ? viewReview() : t === 'payouts' ? viewPayouts() : viewInsights();
    $app.innerHTML = header() + '<main class="wrap main">' + v + '</main>' + nav();
  }
  if (keep) {
    const el = document.getElementById(keep);
    if (el && el.focus) el.focus();
  }
}

/* ---------- loading data ---------- */
async function load() {
  const role = S.me.role, t = S.tab;
  S.err = '';
  const jobs = [];
  if (role !== 'admin') jobs.push(api('GET', '/api/wallet').then((w) => { S.data.wallet = w; S.balance = w.balance; }));
  if (role === 'scout' && t === 'sites') jobs.push(api('GET', '/api/sites/mine').then((r) => { S.data.sites = r.sites; }));
  if (role === 'supplier' && t === 'leads') jobs.push(api('GET', '/api/leads?state=' + S.leadTab).then((r) => { S.data.leads = r.leads; }));
  if (role === 'supplier' && t === 'unlocked') jobs.push(api('GET', '/api/unlocked').then((r) => { S.data.unlocked = r.unlocked; }));
  if (role === 'admin' && t === 'review') jobs.push(api('GET', '/api/admin/sites' + (S.reviewTab === 'pending' ? '?status=pending' : '')).then((r) => { S.data.adminSites = r.sites; }));
  if (role === 'admin' && t === 'payouts') jobs.push(api('GET', '/api/admin/payouts').then((r) => { S.data.payouts = r.payouts; }));
  if (role === 'admin' && t === 'insights') {
    jobs.push(api('GET', '/api/admin/insights').then((r) => { S.data.insights = r; }));
    jobs.push(api('GET', '/api/admin/settings').then((r) => { S.data.settings = r; }));
    jobs.push(api('GET', '/api/admin/users').then((r) => { S.data.users = r.users; }));
  }
  try {
    await Promise.all(jobs);
  } catch (e) {
    S.err = e.message;
  }
  render();
}
async function go(tab, keepScroll) {
  S.tab = tab;
  S.err = '';
  render();
  if (!keepScroll) window.scrollTo(0, 0);
  await load();
}
function afterLogin() {
  S.draft = newDraft();
  S.data = {};
  S.balance = null;
  S.open = null;
  return go(TABS[S.me.role][0][0]);
}

/* ---------- device: photo and GPS ---------- */
function readPhoto(file) {
  if (!file) return;
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1, 960 / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * s);
      c.height = Math.round(img.height * s);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      S.draft.photo = c.toDataURL('image/jpeg', 0.7);
      render();
    };
    img.onerror = () => toast('That file is not a readable image.');
    img.src = fr.result;
  };
  fr.readAsDataURL(file);
}
function stampPhoto(dataUrl, l1, l2) {
  return new Promise((res) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.width;
      c.height = img.height;
      const x = c.getContext('2d');
      x.drawImage(img, 0, 0);
      const h = Math.max(46, Math.round(img.height * 0.09)), fs = Math.round(h * 0.3);
      x.fillStyle = 'rgba(0,0,0,.62)';
      x.fillRect(0, img.height - h, img.width, h);
      x.fillStyle = '#fff';
      x.font = fs + 'px monospace';
      x.textBaseline = 'top';
      x.fillText(l1, 12, img.height - h + h * 0.14);
      x.fillText(l2, 12, img.height - h + h * 0.14 + fs * 1.3);
      res(c.toDataURL('image/jpeg', 0.7));
    };
    img.onerror = () => res(dataUrl);
    img.src = dataUrl;
  });
}

let geoWatch = null, geoTimer = null;
function stopGeo() {
  if (geoWatch != null) { try { navigator.geolocation.clearWatch(geoWatch); } catch (e) { /* ignore */ } geoWatch = null; }
  clearTimeout(geoTimer);
  geoTimer = null;
}
function geoErrMsg(err) {
  if (!window.isSecureContext) return 'Location only works on a secure https page. Open the https link, not a downloaded file.';
  const c = err && err.code;
  if (c === 1) return 'Location is blocked for this page. In Chrome or Safari, tap the lock icon by the address, allow Location, then try again. Also check that Location is on in phone Settings.';
  if (c === 2) return 'The phone could not find its position. Turn on Location in phone settings, choose high accuracy or precise location, and go outdoors.';
  if (c === 3) return 'GPS took too long. Move to open sky and try again.';
  return 'Could not read GPS. Check that Location is on and try again outdoors.';
}
async function checkDup() {
  const d = S.draft;
  if (!d.gps) return;
  try { d.dup = await api('POST', '/api/sites/check', { lat: d.gps.lat, lng: d.gps.lng }); } catch (e) { d.dup = null; toast(e.message); }
  render();
}
function locate() {
  const d = S.draft;
  stopGeo();
  if (!navigator.geolocation) { d.gpsStatus = 'error'; d.gpsMsg = 'This browser cannot read GPS.'; render(); return; }
  d.gpsStatus = 'locating'; d.gpsMsg = ''; d.liveAcc = null; d.dup = null; render();
  let best = null, lastRender = 0;
  const fail = (err) => { stopGeo(); d.gpsStatus = 'error'; d.gpsMsg = geoErrMsg(err); render(); };
  const finish = () => {
    stopGeo();
    if (best) {
      d.gps = { lat: +best.coords.latitude.toFixed(6), lng: +best.coords.longitude.toFixed(6), acc: Math.round(best.coords.accuracy), src: 'gps' };
      d.gpsStatus = 'ok';
      render();
      checkDup();
    } else render();
  };
  const onPos = (p) => {
    if (!best || p.coords.accuracy < best.coords.accuracy) best = p;
    if (p.coords.accuracy <= 20) { finish(); return; }
    const now = Date.now();
    if (now - lastRender > 1000) { lastRender = now; d.liveAcc = Math.round(best.coords.accuracy); render(); }
  };
  const fallback = () => {
    stopGeo();
    try { navigator.geolocation.getCurrentPosition((p) => { best = p; finish(); }, fail, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 }); } catch (e) { fail(e); }
  };
  try {
    geoWatch = navigator.geolocation.watchPosition(onPos, (err) => { if (err && err.code === 1) fail(err); }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
    geoTimer = setTimeout(() => (best ? finish() : fallback()), 12000);
  } catch (e) { fail(e); }
}
function copyText(v) {
  const bad = () => toast('Copy was blocked. Select the number to copy it.');
  try { navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(v).then(() => toast('Copied ' + v), bad) : bad(); } catch (e) { bad(); }
}

/* ---------- actions ---------- */
async function submitReport() {
  const d = S.draft, m = missing(d);
  if (m.length) { toast('Still needed: ' + m.join(', ')); return; }
  if (S.busy) return;
  S.busy = true; render();
  try {
    const photo = await stampPhoto(d.photo, d.gps.lat + ', ' + d.gps.lng + (d.gps.src === 'gps' ? '  ±' + d.gps.acc + ' m' : '  (typed)'), fmtDT(Date.now()) + '  ' + S.me.name);
    const r = await api('POST', '/api/sites', {
      lat: d.gps.lat, lng: d.gps.lng, acc: d.gps.acc, gpsSrc: d.gps.src, name: d.name, locality: d.locality, type: d.type, sub: d.sub, stage: Number(d.stage),
      area: d.area ? Number(d.area) : 0, budget: d.budget, ownerNotified: !!d.notified, photo,
      owner: { name: d.owner, phone: d.ownerPhone }, architect: { name: d.arch, phone: d.archPhone }, engineer: { name: d.eng, phone: d.engPhone }, builder: { name: d.builder, phone: d.builderPhone },
    });
    S.draft = newDraft();
    S.manualOpen = false;
    S.busy = false;
    S.open = r.site.code;
    toast(r.site.code + ' reported. It goes live once the admin verifies it.');
    await go('sites');
  } catch (e) {
    S.busy = false;
    toast(e.message);
    render();
    if (e.data && e.data.duplicate) checkDup();
  }
}
async function guard(fn) {
  try { await fn(); } catch (e) { toast(e.message); render(); }
}
async function act(el) {
  const a = el.dataset.act, v = el.dataset.v;
  switch (a) {
    case 'tab': return go(v);
    case 'retry': return load();
    case 'reload': return location.reload();
    case 'photo': { const i = document.getElementById('photoIn'); if (i) i.click(); return; }
    case 'locate': return locate();
    case 'manual-open': S.manualOpen = true; return render();
    case 'manual-use': {
      const la = parseFloat(S.draft.manual.lat), ln = parseFloat(S.draft.manual.lng);
      if (!(la >= -90 && la <= 90 && ln >= -180 && ln <= 180)) return toast('Enter a valid latitude and longitude.');
      S.draft.gps = { lat: +la.toFixed(6), lng: +ln.toFixed(6), acc: 0, src: 'manual' };
      S.draft.gpsStatus = 'ok'; render();
      return checkDup();
    }
    case 'type': S.draft.type = v; S.draft.sub = S.cfg.types[v][0]; return render();
    case 'submit': return submitReport();
    case 'open-site': S.open = S.open === el.dataset.id ? null : el.dataset.id; return render();
    case 'stage': return guard(async () => {
      const s = document.getElementById('ns_' + el.dataset.id);
      await api('POST', '/api/sites/' + el.dataset.id + '/stage', { stage: Number(s.value) });
      toast('Stage updated. New leads may now be open.');
      await load();
    });
    case 'copy': return copyText(v);
    case 'leadtab': S.leadTab = v; S.data.leads = null; return go('leads', true);
    case 'mytrade': return guard(async () => {
      const set = new Set(S.me.trades);
      set.has(v) ? set.delete(v) : set.add(v);
      if (!set.size) return toast('Keep at least one trade.');
      const r = await api('PUT', '/api/me/trades', { trades: [...set] });
      S.me.trades = r.trades; S.data.leads = null; render(); await load();
    });
    case 'unlock': return guard(async () => {
      el.disabled = true;
      try {
        const r = await api('POST', '/api/leads/unlock', { siteCode: el.dataset.p, tradeId: el.dataset.t });
        S.balance = r.balance; S.data.unlocked = null;
        toast('Unlocked for ' + inr(r.price) + '. Details are in Unlocked.');
        await load();
      } catch (e) {
        if (e.status === 402) { toast(e.message); return go('wallet'); }
        if (e.status === 409) { toast(e.message); return load(); }
        throw e;
      }
    });
    case 'topup': return guard(async () => { const r = await api('POST', '/api/wallet/topup', { amount: Number(v) }); S.balance = r.balance; toast(inr(Number(v)) + ' added.'); await load(); });
    case 'payout': return guard(async () => {
      const w = S.data.wallet;
      const upi = (S.wd.upi || S.me.upi || '').trim();
      const amt = S.wd.amt !== '' ? Number(S.wd.amt) : w.balance;
      const r = await api('POST', '/api/payouts', { upi, amount: amt });
      S.me.upi = upi; S.wd.amt = ''; S.balance = r.balance;
      toast('Payout requested. The admin will pay it to your UPI ID.');
      await load();
    });
    case 'approve': return guard(async () => { await api('POST', '/api/admin/sites/' + el.dataset.id + '/approve'); toast('Approved. Leads are now open to suppliers.'); await load(); });
    case 'reject-ask': S.reject = { code: el.dataset.id, reason: S.cfg.rejectReasons[0] }; return render();
    case 'reject-cancel': S.reject = null; return render();
    case 'reject-do': return guard(async () => { await api('POST', '/api/admin/sites/' + el.dataset.id + '/reject', { reason: S.reject.reason }); S.reject = null; toast('Rejected.'); await load(); });
    case 'reviewtab': S.reviewTab = v; S.data.adminSites = null; return go('review', true);
    case 'payout-paid': return guard(async () => { await api('POST', '/api/admin/payouts/' + el.dataset.id + '/paid'); toast('Marked as paid.'); await load(); });
    case 'payout-reject': return guard(async () => { await api('POST', '/api/admin/payouts/' + el.dataset.id + '/reject'); toast('Money returned to the scout.'); await load(); });
    case 'user-toggle': return guard(async () => { await api('POST', '/api/admin/users/' + el.dataset.id + '/status', { status: v }); await load(); });
    case 'install': if (S.install) { S.install.prompt(); S.install = null; render(); } return;
    case 'logout': return guard(async () => { await api('POST', '/api/auth/logout'); stopGeo(); S.me = null; S.data = {}; S.auth = { step: 'phone', phone: '', exists: null, demoCode: '', code: '', name: '', role: 'scout', kind: 'Public member', trades: [], pass: '' }; render(); });
    case 'auth-back': S.auth.step = 'phone'; S.auth.code = ''; S.auth.demoCode = ''; return render();
    case 'auth-kind': S.auth.kind = v; S.auth.role = el.dataset.role; return render();
    case 'auth-trade': { const t = S.auth.trades, i = t.indexOf(v); i >= 0 ? t.splice(i, 1) : t.push(v); return render(); }
    case 'auth-request': return guard(async () => {
      S.busy = true; render();
      try {
        const r = await api('POST', '/api/auth/request', { phone: S.auth.phone });
        S.auth.step = 'code'; S.auth.exists = r.exists; S.auth.demoCode = r.demoCode || ''; S.auth.code = '';
        if (r.demoCode) S.auth.code = r.demoCode;
      } finally { S.busy = false; render(); }
    });
    case 'auth-verify': return guard(async () => {
      const a = S.auth;
      S.busy = true; render();
      try {
        const r = await api('POST', '/api/auth/verify', { phone: a.phone, code: a.code, name: a.name, role: a.role, kind: a.kind, trades: a.trades, adminPasscode: a.pass });
        S.me = r.user; S.busy = false;
        await afterLogin();
      } finally { S.busy = false; }
    });
  }
}

/* ---------- events ---------- */
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (el) act(el);
});
function setPath(path, val) {
  const k = path.split('.');
  let o = S;
  for (let i = 0; i < k.length - 1; i++) o = o[k[i]];
  o[k[k.length - 1]] = val;
}
document.addEventListener('input', (e) => {
  const t = e.target, b = t.dataset && t.dataset.bind;
  if (b && !t.dataset.check) setPath(b, t.value);
});
document.addEventListener('change', (e) => {
  const t = e.target, d = t.dataset || {};
  if (t.id === 'photoIn') return readPhoto(t.files && t.files[0]);
  if (t.id === 'spot') {
    const s = TEST_SPOTS[parseInt(t.value, 10)];
    if (s) { S.draft.manual.lat = String(s[1]); S.draft.manual.lng = String(s[2]); render(); }
    return;
  }
  if (d.set) {
    const n = Number(t.value);
    api('PUT', '/api/admin/settings', { [d.set]: n })
      .then((r) => { S.data.settings.settings = r.settings; S.cfg.settings = r.settings; toast('Rule updated.'); })
      .catch((err) => { toast(err.message); load(); });
    return;
  }
  if (d.bind) {
    if (d.check) { setPath(d.bind, t.checked); render(); return; }
    setPath(d.bind, t.value);
    if (d.bind === 'draft.stage' || d.bind === 'draft.sub') return; // no redraw needed
    if (d.bind === 'reject.reason') return;
  }
});

/* ---------- start ---------- */
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); S.install = e; if (S.me) render(); });
window.addEventListener('appinstalled', () => { S.install = null; if (S.me) render(); });

async function start() {
  try {
    S.cfg = await api('GET', '/api/config');
    const me = await api('GET', '/api/me');
    S.me = me.user;
  } catch (e) {
    $app.innerHTML = '<div class="wrap auth"><div class="banner bad"><b>Cannot reach SiteScout</b><span>' + esc(e.message) + '</span></div><button class="btn mark" data-act="reload">Try again</button></div>';
    return;
  }
  S.draft = newDraft();
  if (S.me) await afterLogin();
  else render();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
}
start();
